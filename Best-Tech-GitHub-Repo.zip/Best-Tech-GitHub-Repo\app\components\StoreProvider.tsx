"use client";
import { createContext, useContext, useEffect, useState } from "react";

type CartItem = { slug:string; name:string; price:number; qty:number };
type Store = { cart:CartItem[]; add:(item:Omit<CartItem,"qty">,qty?:number)=>void; remove:(slug:string)=>void; count:number; dealerStatus:string; setDealerStatus:(s:string)=>void };
const Ctx=createContext<Store|null>(null);
export function StoreProvider({children}:{children:React.ReactNode}){
  const [cart,setCart]=useState<CartItem[]>([]);
  const [dealerStatus,setDealerStatusState]=useState("guest");
  useEffect(()=>{try{
    // Hydrate the client-only demo store after the initial server render.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setCart(JSON.parse(localStorage.getItem("we-cart")||"[]"));
    setDealerStatusState(localStorage.getItem("we-status")||"guest");
  }catch{}},[]);
  useEffect(()=>{localStorage.setItem("we-cart",JSON.stringify(cart))},[cart]);
  const setDealerStatus=(s:string)=>{setDealerStatusState(s);localStorage.setItem("we-status",s)};
  const add=(item:Omit<CartItem,"qty">,qty=1)=>setCart(c=>{const hit=c.find(x=>x.slug===item.slug);return hit?c.map(x=>x.slug===item.slug?{...x,qty:x.qty+qty}:x):[...c,{...item,qty}]});
  const remove=(slug:string)=>setCart(c=>c.filter(x=>x.slug!==slug));
  return <Ctx.Provider value={{cart,add,remove,count:cart.reduce((n,x)=>n+x.qty,0),dealerStatus,setDealerStatus}}>{children}</Ctx.Provider>
}
export const useStore=()=>{const v=useContext(Ctx);if(!v)throw new Error("StoreProvider missing");return v};


