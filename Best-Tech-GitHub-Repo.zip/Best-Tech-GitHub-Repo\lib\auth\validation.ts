import { z } from "zod";

export const registrationSchema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(190),
  mobile: z.string().trim().regex(/^(?:\+?88)?01[3-9]\d{8}$/, "Enter a valid Bangladesh mobile number"),
  address: z.string().trim().min(10).max(1000),
  password: z.string().min(8).max(100),
});

export const loginSchema = z.object({ identifier: z.string().trim().min(3), password: z.string().min(8).max(100) });


