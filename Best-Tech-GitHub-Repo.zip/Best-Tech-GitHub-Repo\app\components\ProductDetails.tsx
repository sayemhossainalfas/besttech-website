"use client";

import Link from "next/link";
import { Minus, Plus, ShieldCheck, ShoppingBag } from "lucide-react";
import { useMemo, useState } from "react";
import type { PublicProduct } from "@/lib/public-content";
import { money } from "../data";
import { useStore } from "./StoreProvider";
import SafeImage from "./SafeImage";
import ProductCard from "./ProductCard";

export default function ProductDetails({ product, relatedProducts }: { product: PublicProduct; relatedProducts: PublicProduct[] }) {
  const { add, dealerStatus } = useStore();
  const approved = dealerStatus === "approved";
  const price = approved ? product.wholesalePrice : product.retailPrice;
  const [qty, setQty] = useState(approved ? product.moq : 1);
  const [activeIndex, setActiveIndex] = useState(0);
  const galleryImages = useMemo(() => Array.isArray(product.images) && product.images.some(Boolean) ? product.images.filter(Boolean).slice(0,5) : [product.image || "/icon.png"], [product.images,product.image]);
  const activeImage = galleryImages[activeIndex] || galleryImages[0];

  return <><section className="section product-detail-section"><div className="shell"><div className="breadcrumbs product-breadcrumbs"><Link href="/">Home</Link><span>/</span><Link href="/catalog">Catalog</Link><span>/</span><span>{product.name}</span></div><div className="detail"><div><div className="detail-image" style={{background:product.accent,position:"relative"}}><SafeImage src={activeImage} alt={product.name} priority sizes="(max-width:900px) 100vw,50vw"/></div>{galleryImages.length>1&&<div className="product-detail-gallery">{galleryImages.map((image,index)=><button key={`${image}-${index}`} type="button" className={activeIndex===index?"active":""} onClick={()=>setActiveIndex(index)} aria-label={`Show ${product.name} image ${index+1}`}><SafeImage src={image} alt="" sizes="90px"/></button>)}</div>}</div><div className="product-detail-copy"><div className="eyebrow">{product.brand} Â· {product.category}</div><h1>{product.name}</h1><p className="lead">{product.description}</p><div className="detail-price">{money(price)}</div><div className="detail-note">{approved?`Approved wholesale price Â· Minimum order ${product.moq} units`:"Public retail price Â· Wholesale pricing unlocks after approval"}</div><div className="specs">{product.specs.map((spec)=><div className="spec" key={spec}>{spec}</div>)}</div><div className="quantity-row"><div><strong>Order quantity</strong><div className="stock">{product.stock}</div></div><div className="qty"><button onClick={()=>setQty(Math.max(approved?product.moq:1,qty-1))} aria-label="Decrease quantity"><Minus size={15}/></button><span>{qty}</span><button onClick={()=>setQty(qty+1)} aria-label="Increase quantity"><Plus size={15}/></button></div></div><div className="buy-row"><button className="btn btn-primary" onClick={()=>add({slug:product.slug,name:product.name,price},qty)}><ShoppingBag size={17} aria-hidden="true"/> Add to cart</button><Link href="/cart" className="btn btn-dark">Buy now</Link></div><div className="notice"><ShieldCheck size={14} aria-hidden="true"/>Retail checkout is public. Approved wholesale accounts automatically receive protected trade pricing.</div></div></div></div></section>{relatedProducts.length>0&&<section className="section related-products"><div className="shell"><div className="section-head"><div><div className="eyebrow">You may also like</div><h2 className="title">Related products</h2></div><Link href="/catalog" className="btn btn-ghost">View all products</Link></div><div className="product-grid four-up">{relatedProducts.map((item)=><ProductCard key={item.slug} p={item}/>)}</div></div></section>}</>;
}


