"use client";

import Link from "next/link";
import Image from "next/image";
import { LogIn, Menu, ShoppingBag, X } from "lucide-react";
import { useState } from "react";
import { usePathname } from "next/navigation";
import { useStore } from "./StoreProvider";

export default function Header() {
  const [open, setOpen] = useState(false);
  const { count } = useStore();
  const pathname = usePathname();
  if (pathname.startsWith("/admin")) return null;

  const close = () => setOpen(false);

  return (
    <header className="header">
      <div className="topline">
        <div className="shell topline-inner"><span>Best Tech electronics supply across Bangladesh</span><span>Authentic products · Business pricing · Partner support</span></div>
      </div>
      <div className="shell nav">
        <Link href="/" onClick={close}><Image className="logo" src="/website-logo.png" width={215} height={50} priority alt="Best Tech" /></Link>
        <nav className="navlinks" aria-label="Main navigation"><Link href="/catalog">Products</Link><Link href="/brands">Brands</Link><Link href="/blog">Blog</Link><Link href="/about">Company</Link><Link href="/dealer">Dealer program</Link><Link href="/contact">Contact</Link></nav>
        <div className="nav-actions">
          <Link className="icon-btn" href="/cart" aria-label={`Cart with ${count} items`}><ShoppingBag size={18} aria-hidden="true" />{count > 0 && <span className="badge">{count}</span>}</Link>
          <Link className="btn btn-primary btn-sm desktop-only login-cta" href="/account"><LogIn size={16} aria-hidden="true" /> Login / Sign up</Link>
          <button className="icon-btn menu-btn" onClick={() => setOpen(!open)} aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} aria-controls="mobile-navigation">{open ? <X size={20} /> : <Menu size={20} />}</button>
        </div>
      </div>
      {open && <nav id="mobile-navigation" className="mobile-navigation" aria-label="Mobile navigation"><Link onClick={close} href="/catalog">Products</Link><Link onClick={close} href="/brands">Brands</Link><Link onClick={close} href="/blog">Blog</Link><Link onClick={close} href="/about">Company</Link><Link onClick={close} href="/dealer">Dealer program</Link><Link onClick={close} href="/contact">Contact</Link><Link onClick={close} className="btn btn-primary" href="/account"><LogIn size={17} /> Login / Create account</Link></nav>}
    </header>
  );
}
