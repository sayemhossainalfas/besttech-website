import LegalPage from "../components/LegalPage";
export const metadata={title:"Privacy Policy"};
export default function Privacy(){return <LegalPage title="Privacy policy" intro="How Best Tech collects, uses, protects, and manages information when you use our website and services." sections={[
 {title:"Information we collect",paragraphs:["We may collect your name, mobile number, email address, delivery and billing addresses, business details, account credentials, order history, payment status, device information, and communications with our team.","Payment card credentials are processed by the selected payment gateway and should not be stored directly on our servers."]},
 {title:"How information is used",paragraphs:["We use information to create accounts, process and deliver orders, verify wholesale applications, prevent fraud, provide support, maintain business records, improve our services, and send essential transaction notifications.","Promotional communication is sent only where permitted, and you may request to stop receiving marketing messages."]},
 {title:"Sharing and service providers",paragraphs:["Information may be shared only as necessary with payment gateways, couriers, hosting and email providers, professional advisers, regulators, or law-enforcement authorities where legally required. We do not sell personal information."]},
 {title:"Security and retention",paragraphs:["We apply reasonable technical and organisational safeguards including access controls, encrypted connections, password hashing, and restricted administrator permissions. Information is retained only for legitimate operational, accounting, warranty, dispute, and legal purposes."]},
 {title:"Your choices",paragraphs:["You may ask to access, correct, or delete eligible personal information by contacting support. Some transaction records may need to be retained to meet legal, tax, fraud-prevention, or dispute-resolution obligations."]},
 {title:"Cookies and updates",paragraphs:["Cookies are used for sessions, shopping carts, preferences, security, and analytics. This policy may be updated when our services or legal obligations change; the current version will always appear on this page."]}
 ]}/>}


