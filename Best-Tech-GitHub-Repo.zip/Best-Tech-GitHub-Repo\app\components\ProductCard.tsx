"use client";

import Link from "next/link";
import { ArrowUpRight, ShoppingBag } from "lucide-react";
import { money, type Product } from "../data";
import { useStore } from "./StoreProvider";
import SafeImage from "./SafeImage";

type ProductWithImages = Product & { images?: string[] };

export default function ProductCard({ p }: { p: ProductWithImages }) {
  const { add, dealerStatus } = useStore();
  const approved = dealerStatus === "approved";
  const price = approved ? p.wholesalePrice : p.retailPrice;
  const imageSrc = p.images?.find(Boolean) || p.image || "/icon.png";

  return <article className="product-card store-product-card">
    <Link href={`/products/${p.slug}`} className="product-image store-product-media" style={{ background: p.accent || "#f4f4f4" }} aria-label={`View ${p.name}`}>
      <SafeImage src={imageSrc} alt={p.name} sizes="(max-width: 520px) 112px, (max-width: 900px) 50vw, 25vw" />
      <span className="product-tag">{p.stock}</span>
    </Link>
    <div className="product-body store-product-info">
      <span className="product-brand">{p.brand}</span>
      <Link href={`/products/${p.slug}`}><h3 className="product-name">{p.name}</h3></Link>
      <div className="product-meta"><div><div className="price">{money(price)}</div><div className="moq">{approved ? `Approved wholesale Â· MOQ ${p.moq}` : "Retail price"}</div></div><span className="stock">{p.stock}</span></div>
      <div className="product-actions"><button className="btn btn-primary btn-sm" onClick={() => add({ slug: p.slug, name: p.name, price }, approved ? p.moq : 1)}><ShoppingBag size={15} aria-hidden="true"/> Add to cart</button><Link className="btn btn-ghost btn-sm" href={`/products/${p.slug}`} aria-label={`Open ${p.name}`}><ArrowUpRight size={15} aria-hidden="true"/></Link></div>
    </div>
  </article>;
}


