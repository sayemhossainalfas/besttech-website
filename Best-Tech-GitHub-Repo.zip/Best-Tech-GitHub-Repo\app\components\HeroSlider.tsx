"use client";

import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import type { PublicSlide } from "@/lib/public-content";

export default function HeroSlider({ slides }: { slides: PublicSlide[] }) {
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);
  const touchStart = useRef<number | null>(null);
  const go = useCallback((index: number) => setActive((index + slides.length) % slides.length), [slides.length]);

  useEffect(() => {
    if (paused) return;
    const timer = window.setInterval(() => setActive((current) => (current + 1) % slides.length), 6500);
    return () => window.clearInterval(timer);
  }, [paused, slides.length]);

  return (
    <section
      className="slider-hero"
      aria-roledescription="carousel"
      aria-label="Best Tech highlights"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
      onTouchStart={(event) => { touchStart.current = event.touches[0].clientX; }}
      onTouchEnd={(event) => {
        if (touchStart.current === null) return;
        const distance = event.changedTouches[0].clientX - touchStart.current;
        if (Math.abs(distance) > 45) go(active + (distance < 0 ? 1 : -1));
        touchStart.current = null;
      }}
    >
      {slides.map((slide, index) => (
        <article
          className={`hero-slide ${index === active ? "is-active" : ""}`}
          aria-hidden={index !== active}
          key={slide.eyebrow}
        >
          <Image
            className="hero-slide-image"
            src={slide.image}
            alt=""
            fill
            priority={index === 0}
            unoptimized
            sizes="100vw"
            style={{ objectPosition: slide.position }}
          />
          <div className="hero-shade" />
          <div className="shell hero-slide-inner">
            <div className="hero-slide-copy">
              <div className="eyebrow hero-eyebrow">{slide.eyebrow}</div>
              <h1>{slide.title}</h1>
              <p>{slide.copy}</p>
              <div className="hero-actions">
                <Link className="btn btn-primary" href={slide.href}>{slide.primary} <ArrowRight size={17} /></Link>
                <Link className="btn hero-secondary" href={slide.secondaryHref}>{slide.secondary}</Link>
              </div>
            </div>
          </div>
        </article>
      ))}

      <div className="shell hero-slider-controls">
        <div className="hero-progress" aria-label={`Slide ${active + 1} of ${slides.length}`}>
          {slides.map((slide, index) => (
            <button
              className={index === active ? "is-active" : ""}
              key={slide.eyebrow}
              onClick={() => go(index)}
              aria-label={`Show slide ${index + 1}: ${slide.eyebrow}`}
              aria-current={index === active ? "true" : undefined}
            >
              <span>0{index + 1}</span><i />
            </button>
          ))}
        </div>
        <div className="hero-arrows">
          <button onClick={() => go(active - 1)} aria-label="Previous slide"><ArrowLeft size={19} /></button>
          <button onClick={() => go(active + 1)} aria-label="Next slide"><ArrowRight size={19} /></button>
        </div>
      </div>
    </section>
  );
}


