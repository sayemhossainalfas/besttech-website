"use client";

import { useState } from "react";
import { Clock, MapPin, MessageCircle, Phone } from "lucide-react";
import PageHero from "../components/PageHero";

export default function Contact() {
  const [sent, setSent] = useState(false);

  return (
    <>
      <PageHero title="Talk to the Best Tech team" description="For product availability, dealership, corporate supply, or distribution questions, contact our business team." />
      <section className="section-sm">
        <div className="shell feature-grid">
          <div className="grid two">
            <div className="form-card"><MapPin color="var(--rust)" /><h3>Office</h3><p className="muted">Level-05, Rajlaxmi Complex, Uttara, Dhaka 1230</p></div>
            <div className="form-card"><MessageCircle color="var(--rust)" /><h3>WhatsApp</h3><p className="muted">+880 1674-603445</p></div>
            <div className="form-card"><Phone color="var(--rust)" /><h3>Mobile</h3><p className="muted">+880 1674-603445</p></div>
            <div className="form-card"><Clock color="var(--rust)" /><h3>Business hours</h3><p className="muted">Sat-Thu · 10am-7pm</p></div>
          </div>
          {sent ? <div className="success"><h3>Message received</h3><p>Our team will contact you shortly.</p></div> : <form className="form-card form-grid" onSubmit={(event) => { event.preventDefault(); setSent(true); }}><div className="field full"><label>Name *</label><input required /></div><div className="field"><label>Mobile *</label><input required type="tel" /></div><div className="field"><label>Email</label><input type="email" /></div><div className="field full"><label>Message *</label><textarea required /></div><div className="field full"><button className="btn btn-primary">Send message</button></div></form>}
        </div>
      </section>
    </>
  );
}
