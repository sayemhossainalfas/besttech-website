import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth/session";

export const runtime = "nodejs";

const allowedTypes = new Map([["image/jpeg", ".jpg"], ["image/png", ".png"], ["image/webp", ".webp"]]);

export async function POST(request: Request) {
  try {
    await requireAdmin();
    const form = await request.formData();
    const files = form.getAll("files").filter((value): value is File => value instanceof File && value.size > 0);
    if (!files.length) return NextResponse.json({ error: "No image selected" }, { status: 400 });
    if (files.length > 5) return NextResponse.json({ error: "Upload a maximum of 5 images at once" }, { status: 400 });
    const directory = path.join(process.cwd(), "public", "uploads");
    await mkdir(directory, { recursive: true });
    const urls: string[] = [];
    for (const file of files) {
      const extension = allowedTypes.get(file.type);
      if (!extension) return NextResponse.json({ error: `${file.name} is not a JPG, PNG, or WebP image` }, { status: 415 });
      if (file.size > 5 * 1024 * 1024) return NextResponse.json({ error: `${file.name} is larger than 5 MB` }, { status: 413 });
      const filename = `${Date.now()}-${crypto.randomUUID()}${extension}`;
      await writeFile(path.join(directory, filename), Buffer.from(await file.arrayBuffer()), { flag: "wx" });
      urls.push(`/uploads/${filename}`);
    }
    return NextResponse.json({ urls }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message === "UNAUTHORIZED") return NextResponse.json({ error: "Administrator login required" }, { status: 401 });
    console.error("Image upload failed", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Image upload failed" }, { status: 500 });
  }
}


