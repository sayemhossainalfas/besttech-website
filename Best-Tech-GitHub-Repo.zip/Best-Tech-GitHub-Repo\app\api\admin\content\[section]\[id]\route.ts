import { revalidatePath } from "next/cache";
import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { deleteContent, isPersistentSection, updateContent } from "@/lib/admin/content";
import { requireAdmin } from "@/lib/auth/session";

export const dynamic = "force-dynamic";

function errorResponse(error: unknown) {
  if (error instanceof ZodError) return NextResponse.json({ error: error.issues[0]?.message || "Invalid form data" }, { status: 400 });
  if (error instanceof Error && error.message === "UNAUTHORIZED") return NextResponse.json({ error: "Administrator login required" }, { status: 401 });
  const databaseError = error as { code?: string; sqlMessage?: string };
  if (databaseError.code === "ER_DUP_ENTRY") return NextResponse.json({ error: "That slug or SKU already exists. Please use a unique value." }, { status: 409 });
  if (databaseError.code === "ER_ROW_IS_REFERENCED_2") return NextResponse.json({ error: "This record is used by products or orders and cannot be deleted." }, { status: 409 });
  console.error("Admin content mutation failed", error);
  return NextResponse.json({ error: databaseError.sqlMessage || (error instanceof Error ? error.message : "Database request failed") }, { status: 500 });
}

function refreshPublicPages() {
  revalidatePath("/"); revalidatePath("/catalog"); revalidatePath("/brands"); revalidatePath("/blog"); revalidatePath("/sitemap.xml");
}

export async function PUT(request: Request, { params }: { params: Promise<{ section: string; id: string }> }) {
  try {
    const admin = await requireAdmin();
    const { section, id: rawId } = await params;
    if (!isPersistentSection(section)) return NextResponse.json({ error: "Unsupported admin section" }, { status: 404 });
    const id = Number(rawId); if (!Number.isInteger(id) || id < 1) return NextResponse.json({ error: "Invalid record ID" }, { status: 400 });
    const item = await updateContent(section, id, await request.json(), admin);
    if (!item) return NextResponse.json({ error: "Record not found" }, { status: 404 });
    refreshPublicPages();
    return NextResponse.json({ item });
  } catch (error) { return errorResponse(error); }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ section: string; id: string }> }) {
  try {
    await requireAdmin();
    const { section, id: rawId } = await params;
    if (!isPersistentSection(section)) return NextResponse.json({ error: "Unsupported admin section" }, { status: 404 });
    const id = Number(rawId); if (!Number.isInteger(id) || id < 1) return NextResponse.json({ error: "Invalid record ID" }, { status: 400 });
    await deleteContent(section, id); refreshPublicPages();
    return NextResponse.json({ ok: true });
  } catch (error) { return errorResponse(error); }
}


