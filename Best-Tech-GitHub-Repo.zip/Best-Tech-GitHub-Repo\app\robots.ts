import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const base = process.env.NEXT_PUBLIC_SITE_URL || "https://besttech.com.bd";
  return {
    rules: [
      { userAgent: "*", allow: "/", disallow: ["/admin/", "/api/", "/account/", "/checkout/"] },
    ],
    sitemap: `${base}/sitemap.xml`,
    host: base,
  };
}


