"use client";

import Image from "next/image";
import { ImagePlus, Upload } from "lucide-react";
import { useEffect, useId, useState } from "react";

export type AdminRecord = Record<string, unknown> & {
  id: number;
  name: string;
  detail: string;
  status: string;
};

export type AdminReferences = {
  brands: AdminRecord[];
  categories: AdminRecord[];
};

function text(item: AdminRecord | null, key: string, fallback = "") {
  const value = item?.[key];
  return value === null || value === undefined ? fallback : String(value);
}

function checked(item: AdminRecord | null, key: string) {
  return item?.[key] === true || item?.[key] === 1;
}

export function Field({
  label,
  name,
  defaultValue,
  type = "text",
  placeholder,
  full = false,
  required = false,
  min,
  step,
}: {
  label: string;
  name: string;
  defaultValue?: string | number;
  type?: string;
  placeholder?: string;
  full?: boolean;
  required?: boolean;
  min?: number;
  step?: string;
}) {
  const id = useId();

  return (
    <div className={`field ${full ? "full" : ""}`}>
      <label htmlFor={id}>{label}</label>
      <input
        id={id}
        name={name}
        type={type}
        defaultValue={defaultValue}
        placeholder={placeholder}
        required={required}
        min={min}
        step={step}
      />
    </div>
  );
}

export function Select({
  label,
  name,
  children,
  defaultValue,
  full = false,
}: {
  label: string;
  name: string;
  children: React.ReactNode;
  defaultValue?: string | number;
  full?: boolean;
}) {
  const id = useId();

  return (
    <div className={`field ${full ? "full" : ""}`}>
      <label htmlFor={id}>{label}</label>
      <select id={id} name={name} defaultValue={defaultValue}>
        {children}
      </select>
    </div>
  );
}

export function UploadBox({
  name,
  label = "Images",
  compact = false,
  multiple = false,
}: {
  name: string;
  label?: string;
  compact?: boolean;
  multiple?: boolean;
}) {
  const id = useId();
  const [previews, setPreviews] = useState<string[]>([]);

  useEffect(() => {
    return () => {
      previews.forEach((url) => URL.revokeObjectURL(url));
    };
  }, [previews]);

  return (
    <div className="field full">
      <label htmlFor={id}>{label}</label>

      <label className={`admin-dropzone ${compact ? "compact" : ""}`} htmlFor={id}>
        <ImagePlus />
        <strong>Drag & drop images here</strong>
        <span>JPG, PNG or WebP Â· Maximum 5 MB each</span>
        <em>
          <Upload /> Browse files
        </em>

        <input
          id={id}
          name={name}
          type="file"
          accept="image/png,image/jpeg,image/webp"
          multiple={multiple}
          onChange={(event) => {
            const files = Array.from(event.target.files || []);
            const urls = files
              .slice(0, multiple ? 5 : 1)
              .map((file) => URL.createObjectURL(file));

            setPreviews((oldUrls) => {
              oldUrls.forEach((url) => URL.revokeObjectURL(url));
              return urls;
            });
          }}
        />
      </label>

      {previews.length > 0 && (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(90px, 1fr))",
            gap: "10px",
            marginTop: "12px",
          }}
        >
          {previews.map((src, index) => (
            <div
              key={src}
              style={{
                position: "relative",
                aspectRatio: "1",
                borderRadius: "12px",
                overflow: "hidden",
                border: "1px solid #e5e7eb",
                background: "#f8fafc",
              }}
            >
              <Image
                src={src}
                alt={`${label} preview ${index + 1}`}
                fill
                unoptimized
                style={{
                  objectFit: "cover",
                }}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function SeoFields({
  item,
  social = false,
}: {
  item: AdminRecord | null;
  social?: boolean;
}) {
  return (
    <section className="admin-field-section">
      <h3>SEO settings</h3>
      <div className="form-grid">
        <Field label="Meta title" name="metaTitle" defaultValue={text(item, "metaTitle")} />
        <Field label="Meta keywords" name="metaKeywords" defaultValue={text(item, "metaKeywords")} />

        <div className="field full">
          <label>Meta description</label>
          <textarea name="metaDescription" defaultValue={text(item, "metaDescription")} />
          <small>Recommended: 150â€“160 characters</small>
        </div>

        {social && (
          <>
            <Field label="Canonical URL" name="canonicalUrl" defaultValue={text(item, "canonicalUrl")} />
            <Field label="OG title" name="ogTitle" defaultValue={text(item, "ogTitle")} />

            <div className="field full">
              <label>OG description</label>
              <textarea name="ogDescription" defaultValue={text(item, "ogDescription")} />
            </div>

            <Field full label="OG image URL" name="ogImage" defaultValue={text(item, "ogImage")} />
            <UploadBox name="ogImageFile" compact label="Upload OG / social share image" />
          </>
        )}

        <div className="admin-google-preview full">
          <span>Google preview</span>
          <strong>{text(item, "metaTitle", "Page title")}</strong>
          <em>besttech.com.bd â€º page â€º {text(item, "slug", "slug")}</em>
          <p>{text(item, "metaDescription", "Meta description preview will appear hereâ€¦")}</p>
        </div>
      </div>
    </section>
  );
}

function ProductEditor({
  item,
  references,
}: {
  item: AdminRecord | null;
  references: AdminReferences;
}) {
  const images = Array.isArray(item?.images) ? item.images.join("\n") : "";

  return (
    <>
      <section className="admin-field-section">
        <h3>Product information</h3>

        <div className="form-grid">
          <Field label="Title *" name="name" defaultValue={text(item, "name")} required />
          <Field label="SKU *" name="sku" defaultValue={text(item, "sku")} placeholder="GAR-F8-AMOLED" required />
          <Field label="Slug" name="slug" defaultValue={text(item, "slug")} placeholder="garmin-fenix-8" />

          <Select label="Brand" name="brandId" defaultValue={text(item, "brandId")}>
            <option value="">â€” Select â€”</option>
            {references.brands.map((brand) => (
              <option value={brand.id} key={brand.id}>
                {brand.name}
              </option>
            ))}
          </Select>

          <Select label="Category" name="categoryId" defaultValue={text(item, "categoryId")}>
            <option value="">â€” Select â€”</option>
            {references.categories.map((category) => (
              <option value={category.id} key={category.id}>
                {category.name}
              </option>
            ))}
          </Select>

          <Field label="Regular price *" name="retailPrice" type="number" min={0} step="0.01" defaultValue={text(item, "retailPrice", "0")} required />
          <Field label="Sale price" name="salePrice" type="number" min={0} step="0.01" defaultValue={text(item, "salePrice")} />
          <Field label="Wholesale price" name="wholesalePrice" type="number" min={0} step="0.01" defaultValue={text(item, "wholesalePrice")} />
          <Field label="Buying price" name="costPrice" type="number" min={0} step="0.01" defaultValue={text(item, "costPrice")} />
          <Field label="Minimum wholesale qty" name="minimumWholesaleQty" type="number" min={1} defaultValue={text(item, "minimumWholesaleQty", "1")} />
          <Field label="Stock quantity" name="stock" type="number" min={0} defaultValue={text(item, "stock", "0")} required />

          <Select label="Availability" name="availability" defaultValue={text(item, "availability", "in_stock")}>
            <option value="in_stock">In stock</option>
            <option value="preorder">Pre-order</option>
            <option value="out_of_stock">Out of stock</option>
          </Select>

          <Select label="Product status" name="status" defaultValue={text(item, "status", "Published").toLowerCase()}>
            <option value="published">Published</option>
            <option value="draft">Draft</option>
            <option value="disabled">Disabled</option>
          </Select>

          <UploadBox name="productImages" label="Product images" multiple />

          <div className="field full">
            <label>Existing / external image URLs</label>
            <textarea name="imageUrls" defaultValue={images} placeholder="One image URL per line" />
            <small>Uploaded files are added to these URLs.</small>
          </div>

          <Field label="Weight (kg)" name="weight" defaultValue={text(item, "weight")} />
          <Field label="Dimensions" name="dimensions" defaultValue={text(item, "dimensions")} placeholder="L Ã— W Ã— H" />

          <div className="field full">
            <label>Short description</label>
            <textarea name="shortDescription" defaultValue={text(item, "shortDescription")} />
          </div>

          <div className="field full">
            <label>Full description</label>
            <textarea className="tall" name="description" defaultValue={text(item, "description")} />
          </div>

          <Field label="Warranty" name="warranty" defaultValue={text(item, "warranty")} />
          <Field label="Shipping information" name="shippingInfo" defaultValue={text(item, "shippingInfo")} />
          <Field label="Return policy" name="returnPolicy" defaultValue={text(item, "returnPolicy")} />
          <Field label="Package includes" name="packageIncludes" defaultValue={text(item, "packageIncludes")} />
        </div>
      </section>

      <section className="admin-field-section">
        <h3>Merchandising</h3>
        <div className="admin-check-grid">
          <label><input name="isFeatured" type="checkbox" defaultChecked={checked(item, "isFeatured")} /> Featured</label>
          <label><input name="isTopSelling" type="checkbox" defaultChecked={checked(item, "isTopSelling")} /> Best seller</label>
          <label><input name="isNewArrival" type="checkbox" defaultChecked={checked(item, "isNewArrival")} /> New arrival</label>
          <label><input name="isDeal" type="checkbox" defaultChecked={checked(item, "isDeal")} /> Deal</label>
          <label><input name="isTrending" type="checkbox" defaultChecked={checked(item, "isTrending")} /> Trending</label>
          <label><input name="showOnHome" type="checkbox" defaultChecked={checked(item, "showOnHome")} /> Show on home</label>
        </div>
      </section>

      <SeoFields item={item} />
    </>
  );
}

function BlogEditor({ item }: { item: AdminRecord | null }) {
  const tags = Array.isArray(item?.tags) ? item.tags.join(", ") : "";
  const faq = Array.isArray(item?.faq) ? (item.faq as Array<{ question?: string; answer?: string }>) : [];

  return (
    <div className="blog-editor-grid">
      <div>
        <section className="admin-field-section">
          <div className="form-grid">
            <Field full label="Blog title *" name="name" defaultValue={text(item, "name")} required />
            <Field label="Slug" name="slug" defaultValue={text(item, "slug")} />
            <Field label="Author" name="author" defaultValue={text(item, "authorName")} />

            <div className="field full">
              <label>Short description</label>
              <textarea name="shortDescription" defaultValue={text(item, "shortDescription")} />
            </div>
          </div>
        </section>

        <section className="admin-field-section">
          <h3>Body editor</h3>
          <div className="editor-toolbar" aria-hidden="true">
            <b>B</b><i>I</i><u>U</u><span>H2</span><span>H3</span><span>Bullets</span><span>Numbers</span><span>Quote</span><span>Link</span><span>Table</span>
          </div>
          <textarea className="blog-body" name="content" aria-label="Blog body" defaultValue={text(item, "content")} required />
          <small>HTML is supported for structured article content.</small>
        </section>

        <SeoFields item={item} social />

        <section className="admin-field-section">
          <h3>FAQ section</h3>
          {[0, 1, 2, 3, 4].map((index) => (
            <div className="faq-row" key={index}>
              <Field label={`FAQ ${index + 1} question`} name={`faq${index + 1}q`} defaultValue={faq[index]?.question || ""} />
              <div className="field">
                <label>Answer</label>
                <textarea name={`faq${index + 1}a`} defaultValue={faq[index]?.answer || ""} />
              </div>
            </div>
          ))}
        </section>
      </div>

      <aside>
        <section className="admin-field-section">
          <h3>Publish</h3>
          <Select label="Status" name="status" defaultValue={text(item, "status", "Draft").toLowerCase()}>
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </Select>
          <Select label="Category" name="category" defaultValue={text(item, "category", "Buying guide")}>
            <option>Buying guide</option>
            <option>Business insights</option>
            <option>Market insights</option>
          </Select>
          <Field label="Tags" name="tagsText" defaultValue={tags} placeholder="Comma separated" />
        </section>

        <section className="admin-field-section">
          <h3>Featured image</h3>
          <Field full label="Image URL" name="coverImage" defaultValue={text(item, "coverImage")} />
          <Field full label="Alt text" name="coverAlt" defaultValue={text(item, "coverAlt")} />
          <UploadBox name="coverImageFile" compact label="Upload featured image" />
        </section>

        <section className="admin-field-section seo-score">
          <h3>SEO checklist <span>Review</span></h3>
          {["Title", "Slug", "Meta title", "Meta description", "Featured image", "Category", "Article content", "FAQ"].map((label) => (
            <p key={label}>{label}<em>Saved with post</em></p>
          ))}
        </section>
      </aside>
    </div>
  );
}

function BrandEditor({ item }: { item: AdminRecord | null }) {
  return (
    <>
      <section className="admin-field-section">
        <div className="form-grid">
          <Field full label="Brand name *" name="name" defaultValue={text(item, "name")} required />
          <Field label="Slug" name="slug" defaultValue={text(item, "slug")} />
          <Field label="Sort order" name="sortOrder" type="number" defaultValue={text(item, "sortOrder", "0")} />
          <Field full label="Logo URL" name="logoUrl" defaultValue={text(item, "logoUrl")} />
          <UploadBox name="logoFile" compact label="Upload brand logo" />

          <div className="field full">
            <label>Description</label>
            <textarea name="description" defaultValue={text(item, "description")} />
          </div>

          <Select label="Status" name="status" defaultValue={text(item, "status", "Active").toLowerCase()}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </Select>
        </div>
      </section>
      <SeoFields item={item} />
    </>
  );
}

function CategoryEditor({
  item,
  references,
}: {
  item: AdminRecord | null;
  references: AdminReferences;
}) {
  return (
    <>
      <section className="admin-field-section">
        <div className="form-grid">
          <Field full label="Name *" name="name" defaultValue={text(item, "name")} required />
          <Field label="Slug" name="slug" defaultValue={text(item, "slug")} />
          <Field label="Sort order" name="sortOrder" type="number" defaultValue={text(item, "sortOrder", "0")} />

          <Select full label="Parent category" name="parentId" defaultValue={text(item, "parentId")}>
            <option value="">â€” None â€”</option>
            {references.categories
              .filter((category) => category.id !== item?.id)
              .map((category) => (
                <option value={category.id} key={category.id}>
                  {category.name}
                </option>
              ))}
          </Select>

          <Field label="Icon / emoji" name="icon" defaultValue={text(item, "icon")} placeholder="âŒš or ðŸ“·" />
          <Field label="Image URL" name="imageUrl" defaultValue={text(item, "imageUrl")} />
          <UploadBox name="categoryImageFile" compact label="Upload category image" />

          <div className="field full">
            <label>Description</label>
            <textarea name="description" defaultValue={text(item, "description")} />
          </div>

          <Select label="Status" name="status" defaultValue={text(item, "status", "Active").toLowerCase()}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </Select>
        </div>
      </section>
      <SeoFields item={item} />
    </>
  );
}

function SliderEditor({ item }: { item: AdminRecord | null }) {
  return (
    <section className="admin-field-section">
      <div className="form-grid">
        <Field full label="Slide title *" name="name" defaultValue={text(item, "name")} required />
        <Field label="Eyebrow" name="eyebrow" defaultValue={text(item, "eyebrow")} />
        <Field label="Sort order" name="sortOrder" type="number" defaultValue={text(item, "sortOrder", "0")} />

        <div className="field full">
          <label>Description</label>
          <textarea name="description" defaultValue={text(item, "description")} />
        </div>

        <Field full label="Image URL *" name="imageUrl" defaultValue={text(item, "imageUrl")} />
        <UploadBox name="sliderImageFile" compact label="Upload slide image" />
        <Field label="Image position" name="imagePosition" defaultValue={text(item, "imagePosition", "center")} placeholder="center 43%" />
        <Field label="Primary button label" name="buttonLabel" defaultValue={text(item, "buttonLabel")} />
        <Field label="Primary button URL" name="buttonUrl" defaultValue={text(item, "buttonUrl")} />
        <Field label="Secondary button label" name="secondaryButtonLabel" defaultValue={text(item, "secondaryButtonLabel")} />
        <Field label="Secondary button URL" name="secondaryButtonUrl" defaultValue={text(item, "secondaryButtonUrl")} />

        <Select label="Status" name="status" defaultValue={text(item, "status", "Active").toLowerCase()}>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </Select>
      </div>
    </section>
  );
}

export default function AdminEditorFields({
  section,
  item,
  references,
}: {
  section: string;
  item: AdminRecord | null;
  references: AdminReferences;
}) {
  if (section === "products") return <ProductEditor item={item} references={references} />;
  if (section === "blog") return <BlogEditor item={item} />;
  if (section === "categories") return <CategoryEditor item={item} references={references} />;
  if (section === "brands") return <BrandEditor item={item} />;
  if (section === "sliders") return <SliderEditor item={item} />;

  return (
    <div className="form-grid">
      <Field full label="Title / name *" name="name" defaultValue={text(item, "name")} required />

      <div className="field full">
        <label>Details</label>
        <textarea name="detail" defaultValue={text(item, "detail")} />
      </div>

      <Select label="Status" name="status" defaultValue={text(item, "status", "Active")}>
        <option>Active</option>
        <option>Pending</option>
        <option>Approved</option>
        <option>Disabled</option>
      </Select>
    </div>
  );
}


