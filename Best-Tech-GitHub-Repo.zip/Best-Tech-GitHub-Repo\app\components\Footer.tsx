"use client";

import Link from "next/link";
import Image from "next/image";
import { Facebook, Instagram, MapPin, MessageCircle, Music2, Phone } from "lucide-react";
import { usePathname } from "next/navigation";

export default function Footer() {
  const pathname = usePathname();
  if (pathname.startsWith("/admin")) return null;

  return (
    <>
      <footer className="footer">
        <div className="shell">
          <div className="footer-grid footer-grid-rich">
            <div>
              <Image className="footer-logo" src="/footer-logo.png" width={210} height={50} alt="Best Tech" />
              <p style={{ maxWidth: 370 }}>
                Best Tech supplies authentic electronics, retail service, and dependable wholesale support across Bangladesh.
              </p>
              <div className="social-row">
                <a className="social facebook" aria-label="Facebook" href="https://www.facebook.com/BestTechLtd" target="_blank" rel="noreferrer"><Facebook /></a>
                <a className="social instagram" aria-label="Instagram" href="https://www.instagram.com/BestTechLtd/" target="_blank" rel="noreferrer"><Instagram /></a>
                <a className="social tiktok" aria-label="TikTok" href="https://www.tiktok.com/BestTechLtd/" target="_blank" rel="noreferrer"><Music2 /></a>
              </div>
            </div>
            <div><h4>Shop</h4><Link href="/catalog">All products</Link><Link href="/brands">Brands</Link><Link href="/blog">Blog & guides</Link><Link href="/dealer">Wholesale program</Link></div>
            <div><h4>Information</h4><Link href="/about">About us</Link><Link href="/contact">Contact</Link><Link href="/privacy-policy">Privacy policy</Link><Link href="/return-policy">Return policy</Link><Link href="/terms">Terms & conditions</Link><Link href="/sitemap-page">Sitemap</Link></div>
            <div className="footer-contact">
              <h4>Contact us</h4>
              <p><Phone size={15} /><a href="tel:+8801674603445">+880 1674-603445</a></p>
              <p><MessageCircle size={15} /><a href="https://wa.me/8801674603445" target="_blank" rel="noreferrer">WhatsApp: +880 1674-603445</a></p>
              <p><MapPin size={16} /><span><b>Office</b> - Level-05, Rajlaxmi Complex, Uttara, Dhaka 1230</span></p>
            </div>
          </div>
          <div className="copyright"><span>Copyright 2026 Best Tech. All rights reserved.</span><span><Link href="/privacy-policy">Privacy</Link> · <Link href="/terms">Terms</Link></span></div>
        </div>
      </footer>
      <a className="whatsapp" href="https://wa.me/8801674603445" target="_blank" rel="noreferrer" aria-label="Contact on WhatsApp"><MessageCircle size={24} /></a>
    </>
  );
}

