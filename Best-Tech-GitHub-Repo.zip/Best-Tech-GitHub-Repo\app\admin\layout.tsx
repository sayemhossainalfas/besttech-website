import AdminShell from "../components/AdminShell";
import {redirect} from "next/navigation";
import {getSession} from "../../lib/auth/session";
export default async function AdminLayout({children}:{children:React.ReactNode}){if(process.env.DATABASE_URL){const session=await getSession();if(!session||session.role!=="admin")redirect("/account")}return <AdminShell>{children}</AdminShell>}


