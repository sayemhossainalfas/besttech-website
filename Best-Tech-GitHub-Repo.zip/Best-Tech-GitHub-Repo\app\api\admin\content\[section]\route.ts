import { revalidatePath } from "next/cache";
import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { createContent, isPersistentSection, listContent } from "@/lib/admin/content";
import { requireAdmin } from "@/lib/auth/session";

export const dynamic = "force-dynamic";

function errorResponse(error: unknown) {
  if (error instanceof ZodError) return NextResponse.json({ error: error.issues[0]?.message || "Invalid form data" }, { status: 400 });
  if (error instanceof Error && error.message === "UNAUTHORIZED") return NextResponse.json({ error: "Administrator login required" }, { status: 401 });
  const databaseError = error as { code?: string; sqlMessage?: string };
  if (databaseError.code === "ER_DUP_ENTRY") return NextResponse.json({ error: "That slug or SKU already exists. Please use a unique value." }, { status: 409 });
  console.error("Admin content request failed", error);
  return NextResponse.json({ error: databaseError.sqlMessage || (error instanceof Error ? error.message : "Database request failed") }, { status: 500 });
}

export async function GET(_request: Request, { params }: { params: Promise<{ section: string }> }) {
  try {
    await requireAdmin();
    const { section } = await params;
    if (!isPersistentSection(section)) return NextResponse.json({ error: "Unsupported admin section" }, { status: 404 });
    return NextResponse.json({ items: await listContent(section) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) { return errorResponse(error); }
}

export async function POST(request: Request, { params }: { params: Promise<{ section: string }> }) {
  try {
    const admin = await requireAdmin();
    const { section } = await params;
    if (!isPersistentSection(section)) return NextResponse.json({ error: "Unsupported admin section" }, { status: 404 });
    const item = await createContent(section, await request.json(), admin);
    revalidatePath("/"); revalidatePath("/catalog"); revalidatePath("/brands"); revalidatePath("/blog"); revalidatePath("/sitemap.xml");
    return NextResponse.json({ item }, { status: 201 });
  } catch (error) { return errorResponse(error); }
}


