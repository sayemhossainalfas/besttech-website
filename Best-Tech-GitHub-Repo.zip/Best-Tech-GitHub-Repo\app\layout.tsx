import type { Metadata } from "next";
import "./globals.css";
import Header from "./components/Header";
import Footer from "./components/Footer";
import { StoreProvider } from "./components/StoreProvider";

export const metadata: Metadata = { metadataBase:new URL(process.env.NEXT_PUBLIC_SITE_URL||"https://besttech.com.bd"), title:{default:"Best Tech Bangladesh",template:"%s | Best Tech"}, description:"Premium electronics retail, B2B distribution, and wholesale supply in Bangladesh.", alternates:{canonical:"/"}, openGraph:{type:"website",siteName:"Best Tech",url:"/",title:"Best Tech Bangladesh",description:"Authentic global technology, retail service, and approved wholesale pricing across Bangladesh."} };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><StoreProvider><Header/><main>{children}</main><Footer/></StoreProvider></body></html>}


