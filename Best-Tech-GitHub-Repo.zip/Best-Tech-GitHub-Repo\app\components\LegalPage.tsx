import PageHero from "./PageHero";
export type LegalSection={title:string;paragraphs:string[]};
export default function LegalPage({title,intro,updated="19 June 2026",sections}:{title:string;intro:string;updated?:string;sections:LegalSection[]}){return <><PageHero title={title} description={intro}/><section className="section-sm"><div className="shell legal-layout"><aside><strong>Last updated</strong><span>{updated}</span><p>Questions?</p><a href="mailto:support@besttech.com.bd">support@besttech.com.bd</a></aside><article>{sections.map(s=><section key={s.title}><h2>{s.title}</h2>{s.paragraphs.map((p,i)=><p key={i}>{p}</p>)}</section>)}</article></div></section></>}


