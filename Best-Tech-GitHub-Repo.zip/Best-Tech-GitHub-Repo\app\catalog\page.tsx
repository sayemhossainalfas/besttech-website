import { getPublicBrands, getPublicCategories, getPublicProducts } from "@/lib/public-content";
import CatalogClient from "../components/CatalogClient";

export const dynamic="force-dynamic";
export const revalidate=0;
export default async function Catalog({searchParams}:{searchParams:Promise<{category?:string;brand?:string}>}){const [products,brands,categories,params]=await Promise.all([getPublicProducts(),getPublicBrands(),getPublicCategories(),searchParams]);return <CatalogClient products={products} brands={brands} categories={categories} initialCategory={params.category||"All"} initialBrand={params.brand||"All"}/>}


