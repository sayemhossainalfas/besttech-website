import Link from "next/link";import PageHero from "../components/PageHero";
const groups=[{title:"Shopping",links:[["All products","/catalog"],["Brands","/brands"],["Cart","/cart"]]},{title:"Company",links:[["About us","/about"],["Contact","/contact"],["Dealer program","/dealer"],["Wholesale inquiry","/inquiry"]]},{title:"Account",links:[["Login & account","/account"],["Wholesale application","/dealer"]]},{title:"Resources",links:[["Blog","/blog"],["Privacy policy","/privacy-policy"],["Return policy","/return-policy"],["Terms & conditions","/terms"]]}];
export default function SitemapPage(){return <><PageHero title="Sitemap" description="Find every important shopping, company, account, and information page."/><section className="section-sm"><div className="shell sitemap-grid">{groups.map(g=><div className="form-card" key={g.title}><h2>{g.title}</h2>{g.links.map(([label,url])=><Link key={url} href={url}>{label} â†’</Link>)}</div>)}</div></section></>}


