import Link from "next/link";
export default function PageHero({title,description}:{title:string,description:string}){return <section className="page-hero"><div className="shell"><div className="breadcrumbs"><Link href="/">Home</Link><span>/</span><span>{title}</span></div><h1 className="title">{title}</h1><p className="lead">{description}</p></div></section>}


