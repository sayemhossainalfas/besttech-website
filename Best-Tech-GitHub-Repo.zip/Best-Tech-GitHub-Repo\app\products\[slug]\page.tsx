import { notFound } from "next/navigation";
import { getPublicProduct, getPublicProducts } from "@/lib/public-content";
import ProductDetails from "@/app/components/ProductDetails";

export const dynamic = "force-dynamic";

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const product = await getPublicProduct(slug);

  if (!product) {
    notFound();
  }

  const allProducts = await getPublicProducts();

  const relatedProducts = allProducts
    .filter((item) => item.slug !== product.slug)
    .slice(0, 4);

  return (
    <ProductDetails
      product={product}
      relatedProducts={relatedProducts}
    />
  );
}

