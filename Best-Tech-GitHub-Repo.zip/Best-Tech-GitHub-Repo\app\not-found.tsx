import Link from "next/link";
export default function NotFound(){return <section className="section"><div className="shell" style={{textAlign:"center"}}><div className="eyebrow" style={{justifyContent:"center"}}>404</div><h1 className="display">Page not found.</h1><p className="lead" style={{margin:"0 auto 25px"}}>The page may have moved, but the wholesale catalog is ready.</p><Link className="btn btn-primary" href="/catalog">Go to catalog</Link></div></section>}


