"use client";

import Image from "next/image";
import { ImageOff } from "lucide-react";
import { useState } from "react";

type SafeImageProps = { src?: string; alt: string; sizes: string; priority?: boolean; className?: string };

export default function SafeImage({ src, alt, sizes, priority = false, className }: SafeImageProps) {
  const [failed, setFailed] = useState(!src);
  if (failed || !src) return <div className="media-fallback" role="img" aria-label={`${alt} image unavailable`}><ImageOff aria-hidden="true"/><span>Image unavailable</span><small>{alt}</small></div>;
  return <Image src={src} alt={alt} fill unoptimized priority={priority} sizes={sizes} className={className} onError={() => setFailed(true)}/>;
}


