import type { PublicBrand } from "@/lib/public-content";
export default function BrandMarquee({brands}:{brands:PublicBrand[]}){const source=brands.length?brands:[{name:"Best Tech",line:"Technology distribution",detail:""}];const items=[...source,...source];return <section className="brand-marquee" aria-label="Brands we distribute"><div className="brand-marquee-track">{items.map((brand,i)=><div className="brand-marquee-item" aria-hidden={i>=source.length} key={`${brand.name}-${i}`}><strong>{brand.name}</strong><span>{brand.line}</span></div>)}</div></section>}


