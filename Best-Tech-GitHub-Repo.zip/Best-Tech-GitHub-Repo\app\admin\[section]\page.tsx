import { notFound } from "next/navigation";
import AdminModule from "../../components/AdminModule";
import InvoiceBuilder from "../../components/InvoiceBuilder";

const config: Record<string, { title: string; description: string }> = {
  sliders: { title: "Homepage slider", description: "Create, reorder, publish, and edit homepage campaigns." },
  products: { title: "Products", description: "Manage retail and protected wholesale prices, stock, images, and SEO." },
  categories: { title: "Categories", description: "Organise the public catalog and product navigation." },
  brands: { title: "Brands", description: "Add brands, upload logos, and manage brand landing pages." },
  orders: { title: "Orders", description: "Process retail and wholesale orders, payments, and fulfilment status." },
  customers: { title: "Customers", description: "Manage registered customers, addresses, activity, and access." },
  wholesalers: { title: "Wholesalers", description: "Review applications and approve or reject protected pricing access." },
  blog: { title: "Blog posts", description: "Create, edit, publish, delete, and optimise articles for search." },
  settings: { title: "Settings", description: "Configure store details, payments, email, delivery, and social profiles." },
};

export default async function AdminSection({ params }: { params: Promise<{ section: string }> }) {
  const { section } = await params;
  if (section === "invoices") return <InvoiceBuilder />;
  const item = config[section];
  if (!item) notFound();
  return <AdminModule section={section} {...item} />;
}
