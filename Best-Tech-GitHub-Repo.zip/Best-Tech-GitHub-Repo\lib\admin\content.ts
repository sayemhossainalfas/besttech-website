import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import type { SessionUser } from "../auth/session";
import { getDb } from "../db";
import { blogPosts, brands, categories, products, sliders } from "../db/schema";

export const persistentSections = ["products", "blog", "brands", "categories", "sliders"] as const;
export type PersistentSection = (typeof persistentSections)[number];
export type AdminContentRecord = Record<string, unknown> & { id: number; name: string; detail: string; status: string };

const optionalText = z.string().trim().optional().default("");
const optionalNumber = z.union([z.string(), z.number(), z.null(), z.undefined()]).transform((value) => {
  if (value === "" || value === null || value === undefined) return null;
  const number = Number(value);
  if (!Number.isFinite(number)) throw new Error("A numeric field contains an invalid value");
  return number;
});
const numberValue = z.coerce.number().finite();
const integerValue = z.coerce.number().int().min(0);
const booleanValue = z.union([z.boolean(), z.string(), z.number(), z.undefined()]).transform((value) => value === true || value === "true" || value === "on" || value === 1 || value === "1");

const productSchema = z.object({
  name: z.string().trim().min(2, "Product title is required"),
  slug: optionalText,
  sku: z.string().trim().min(1, "SKU is required"),
  brandId: optionalNumber,
  categoryId: optionalNumber,
  shortDescription: optionalText,
  description: optionalText,
  retailPrice: numberValue.min(0),
  salePrice: optionalNumber,
  wholesalePrice: optionalNumber,
  costPrice: optionalNumber,
  minimumWholesaleQty: z.coerce.number().int().min(1).default(1),
  stock: integerValue,
  availability: z.enum(["in_stock", "preorder", "out_of_stock"]).default("in_stock"),
  images: z.array(z.string().trim().min(1)).default([]),
  specifications: z.record(z.string(), z.string()).optional().default({}),
  weight: optionalText,
  dimensions: optionalText,
  warranty: optionalText,
  shippingInfo: optionalText,
  returnPolicy: optionalText,
  packageIncludes: optionalText,
  isFeatured: booleanValue,
  isTopSelling: booleanValue,
  isNewArrival: booleanValue,
  isDeal: booleanValue,
  isTrending: booleanValue,
  showOnHome: booleanValue,
  status: z.enum(["draft", "published", "disabled"]).default("published"),
  metaTitle: optionalText,
  metaKeywords: optionalText,
  metaDescription: optionalText,
});

const brandSchema = z.object({
  name: z.string().trim().min(2, "Brand name is required"),
  slug: optionalText,
  logoUrl: optionalText,
  description: optionalText,
  status: z.enum(["active", "inactive"]).default("active"),
  sortOrder: z.coerce.number().int().default(0),
  metaTitle: optionalText,
  metaDescription: optionalText,
});

const categorySchema = z.object({
  name: z.string().trim().min(2, "Category name is required"),
  slug: optionalText,
  imageUrl: optionalText,
  icon: optionalText,
  description: optionalText,
  parentId: optionalNumber,
  status: z.enum(["active", "inactive"]).default("active"),
  sortOrder: z.coerce.number().int().default(0),
  metaTitle: optionalText,
  metaDescription: optionalText,
});

const sliderSchema = z.object({
  name: z.string().trim().min(2, "Slide title is required"),
  eyebrow: optionalText,
  description: optionalText,
  imageUrl: z.string().trim().min(1, "Slide image is required"),
  buttonLabel: optionalText,
  buttonUrl: optionalText,
  secondaryButtonLabel: optionalText,
  secondaryButtonUrl: optionalText,
  imagePosition: optionalText,
  status: z.enum(["active", "inactive"]).default("active"),
  sortOrder: z.coerce.number().int().default(0),
});

const blogSchema = z.object({
  name: z.string().trim().min(2, "Blog title is required"),
  slug: optionalText,
  shortDescription: optionalText,
  content: z.string().trim().min(1, "Blog content is required"),
  coverImage: optionalText,
  coverAlt: optionalText,
  author: optionalText,
  category: optionalText,
  tags: z.array(z.string()).default([]),
  status: z.enum(["draft", "published"]).default("draft"),
  metaTitle: optionalText,
  metaKeywords: optionalText,
  metaDescription: optionalText,
  canonicalUrl: optionalText,
  ogTitle: optionalText,
  ogDescription: optionalText,
  ogImage: optionalText,
  faq: z.array(z.object({ question: z.string(), answer: z.string() })).default([]),
});

function slugify(value: string) {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 240);
}

function titleCase(value: string) {
  return value.replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function money(value: string | number | null) {
  return Number(value || 0).toLocaleString("en-BD");
}

function productRecord(row: { product: typeof products.$inferSelect; brandName: string | null; categoryName: string | null }): AdminContentRecord {
  const product = row.product;
  return {
    ...product,
    name: product.name,
    detail: `${product.sku} Â· Stock ${product.stock} Â· à§³${money(product.retailPrice)}`,
    status: titleCase(product.status),
    brandName: row.brandName,
    categoryName: row.categoryName,
    retailPrice: Number(product.retailPrice),
    salePrice: product.salePrice ? Number(product.salePrice) : null,
    wholesalePrice: product.wholesalePrice ? Number(product.wholesalePrice) : null,
    costPrice: product.costPrice ? Number(product.costPrice) : null,
    metaTitle: product.seoTitle,
    metaDescription: product.seoDescription,
  };
}

async function getProduct(id: number) {
  const db = getDb();
  const rows = await db.select({ product: products, brandName: brands.name, categoryName: categories.name })
    .from(products)
    .leftJoin(brands, eq(products.brandId, brands.id))
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.id, id));
  return rows[0] ? productRecord(rows[0]) : null;
}

export async function listContent(section: PersistentSection): Promise<AdminContentRecord[]> {
  const db = getDb();
  if (section === "products") {
    const rows = await db.select({ product: products, brandName: brands.name, categoryName: categories.name })
      .from(products).leftJoin(brands, eq(products.brandId, brands.id)).leftJoin(categories, eq(products.categoryId, categories.id)).orderBy(desc(products.updatedAt));
    return rows.map(productRecord);
  }
  if (section === "brands") return (await db.select().from(brands).orderBy(brands.sortOrder, brands.name)).map((item) => ({ ...item, name: item.name, detail: `${item.slug}${item.logoUrl ? " Â· Logo uploaded" : ""}`, status: item.isActive ? "Active" : "Inactive", metaTitle: item.seoTitle, metaDescription: item.seoDescription }));
  if (section === "categories") return (await db.select().from(categories).orderBy(categories.sortOrder, categories.name)).map((item) => ({ ...item, name: item.name, detail: item.description || item.slug, status: item.isActive ? "Active" : "Inactive", metaTitle: item.seoTitle, metaDescription: item.seoDescription }));
  if (section === "sliders") return (await db.select().from(sliders).orderBy(sliders.sortOrder, sliders.id)).map((item) => ({ ...item, name: item.title, detail: item.description || item.eyebrow || "Homepage slide", status: item.isActive ? "Active" : "Inactive" }));
  return (await db.select().from(blogPosts).orderBy(desc(blogPosts.updatedAt))).map((item) => ({ ...item, name: item.title, detail: item.excerpt || item.category || "Blog post", status: titleCase(item.status), shortDescription: item.excerpt, metaTitle: item.seoTitle, metaDescription: item.seoDescription }));
}

export async function createContent(section: PersistentSection, input: unknown, admin: SessionUser) {
  const db = getDb();
  if (section === "products") {
    const data = productSchema.parse(input);
    const result = await db.insert(products).values({ name: data.name, slug: data.slug || slugify(data.name), sku: data.sku, brandId: data.brandId, categoryId: data.categoryId, shortDescription: data.shortDescription || null, description: data.description || null, retailPrice: data.retailPrice.toFixed(2), salePrice: data.salePrice?.toFixed(2) || null, wholesalePrice: data.wholesalePrice?.toFixed(2) || null, costPrice: data.costPrice?.toFixed(2) || null, minimumWholesaleQty: data.minimumWholesaleQty, stock: data.stock, images: data.images, specifications: data.specifications, availability: data.availability, weight: data.weight || null, dimensions: data.dimensions || null, warranty: data.warranty || null, shippingInfo: data.shippingInfo || null, returnPolicy: data.returnPolicy || null, packageIncludes: data.packageIncludes || null, isFeatured: data.isFeatured, isTopSelling: data.isTopSelling, isNewArrival: data.isNewArrival, isDeal: data.isDeal, isTrending: data.isTrending, showOnHome: data.showOnHome, status: data.status, isPublished: data.status === "published", seoTitle: data.metaTitle || null, metaKeywords: data.metaKeywords || null, seoDescription: data.metaDescription || null }).returning({ id: products.id });
    return getProduct(result[0].id);
  }
  if (section === "brands") {
    const data = brandSchema.parse(input); const result = await db.insert(brands).values({ name: data.name, slug: data.slug || slugify(data.name), logoUrl: data.logoUrl || null, description: data.description || null, isActive: data.status === "active", sortOrder: data.sortOrder, seoTitle: data.metaTitle || null, seoDescription: data.metaDescription || null }).returning({ id: brands.id });
    return (await listContent(section)).find((item) => item.id === result[0].id) || null;
  }
  if (section === "categories") {
    const data = categorySchema.parse(input); const result = await db.insert(categories).values({ name: data.name, slug: data.slug || slugify(data.name), imageUrl: data.imageUrl || null, icon: data.icon || null, description: data.description || null, parentId: data.parentId, isActive: data.status === "active", sortOrder: data.sortOrder, seoTitle: data.metaTitle || null, seoDescription: data.metaDescription || null }).returning({ id: categories.id });
    return (await listContent(section)).find((item) => item.id === result[0].id) || null;
  }
  if (section === "sliders") {
    const data = sliderSchema.parse(input); const result = await db.insert(sliders).values({ title: data.name, eyebrow: data.eyebrow || null, description: data.description || null, imageUrl: data.imageUrl, buttonLabel: data.buttonLabel || null, buttonUrl: data.buttonUrl || null, secondaryButtonLabel: data.secondaryButtonLabel || null, secondaryButtonUrl: data.secondaryButtonUrl || null, imagePosition: data.imagePosition || "center", isActive: data.status === "active", sortOrder: data.sortOrder }).returning({ id: sliders.id });
    return (await listContent(section)).find((item) => item.id === result[0].id) || null;
  }
  const data = blogSchema.parse(input); const result = await db.insert(blogPosts).values({ title: data.name, slug: data.slug || slugify(data.name), excerpt: data.shortDescription || null, content: data.content, coverImage: data.coverImage || null, coverAlt: data.coverAlt || null, authorName: data.author || admin.name, authorId: admin.id, category: data.category || null, tags: data.tags, status: data.status, seoTitle: data.metaTitle || null, metaKeywords: data.metaKeywords || null, seoDescription: data.metaDescription || null, canonicalUrl: data.canonicalUrl || null, ogTitle: data.ogTitle || null, ogDescription: data.ogDescription || null, ogImage: data.ogImage || null, faq: data.faq, publishedAt: data.status === "published" ? new Date() : null }).returning({ id: blogPosts.id });
  return (await listContent(section)).find((item) => item.id === result[0].id) || null;
}

export async function updateContent(section: PersistentSection, id: number, input: unknown, admin: SessionUser) {
  const db = getDb();
  if (section === "products") {
    const data = productSchema.parse(input); await db.update(products).set({ name: data.name, slug: data.slug || slugify(data.name), sku: data.sku, brandId: data.brandId, categoryId: data.categoryId, shortDescription: data.shortDescription || null, description: data.description || null, retailPrice: data.retailPrice.toFixed(2), salePrice: data.salePrice?.toFixed(2) || null, wholesalePrice: data.wholesalePrice?.toFixed(2) || null, costPrice: data.costPrice?.toFixed(2) || null, minimumWholesaleQty: data.minimumWholesaleQty, stock: data.stock, images: data.images, specifications: data.specifications, availability: data.availability, weight: data.weight || null, dimensions: data.dimensions || null, warranty: data.warranty || null, shippingInfo: data.shippingInfo || null, returnPolicy: data.returnPolicy || null, packageIncludes: data.packageIncludes || null, isFeatured: data.isFeatured, isTopSelling: data.isTopSelling, isNewArrival: data.isNewArrival, isDeal: data.isDeal, isTrending: data.isTrending, showOnHome: data.showOnHome, status: data.status, isPublished: data.status === "published", seoTitle: data.metaTitle || null, metaKeywords: data.metaKeywords || null, seoDescription: data.metaDescription || null }).where(eq(products.id, id));
    return getProduct(id);
  }
  if (section === "brands") { const data = brandSchema.parse(input); await db.update(brands).set({ name: data.name, slug: data.slug || slugify(data.name), logoUrl: data.logoUrl || null, description: data.description || null, isActive: data.status === "active", sortOrder: data.sortOrder, seoTitle: data.metaTitle || null, seoDescription: data.metaDescription || null }).where(eq(brands.id, id)); }
  else if (section === "categories") { const data = categorySchema.parse(input); await db.update(categories).set({ name: data.name, slug: data.slug || slugify(data.name), imageUrl: data.imageUrl || null, icon: data.icon || null, description: data.description || null, parentId: data.parentId, isActive: data.status === "active", sortOrder: data.sortOrder, seoTitle: data.metaTitle || null, seoDescription: data.metaDescription || null }).where(eq(categories.id, id)); }
  else if (section === "sliders") { const data = sliderSchema.parse(input); await db.update(sliders).set({ title: data.name, eyebrow: data.eyebrow || null, description: data.description || null, imageUrl: data.imageUrl, buttonLabel: data.buttonLabel || null, buttonUrl: data.buttonUrl || null, secondaryButtonLabel: data.secondaryButtonLabel || null, secondaryButtonUrl: data.secondaryButtonUrl || null, imagePosition: data.imagePosition || "center", isActive: data.status === "active", sortOrder: data.sortOrder }).where(eq(sliders.id, id)); }
  else { const data = blogSchema.parse(input); await db.update(blogPosts).set({ title: data.name, slug: data.slug || slugify(data.name), excerpt: data.shortDescription || null, content: data.content, coverImage: data.coverImage || null, coverAlt: data.coverAlt || null, authorName: data.author || admin.name, category: data.category || null, tags: data.tags, status: data.status, seoTitle: data.metaTitle || null, metaKeywords: data.metaKeywords || null, seoDescription: data.metaDescription || null, canonicalUrl: data.canonicalUrl || null, ogTitle: data.ogTitle || null, ogDescription: data.ogDescription || null, ogImage: data.ogImage || null, faq: data.faq, publishedAt: data.status === "published" ? new Date() : null }).where(eq(blogPosts.id, id)); }
  return (await listContent(section)).find((item) => item.id === id) || null;
}

export async function deleteContent(section: PersistentSection, id: number) {
  const db = getDb();
  if (section === "products") await db.delete(products).where(eq(products.id, id));
  else if (section === "brands") await db.delete(brands).where(eq(brands.id, id));
  else if (section === "categories") await db.delete(categories).where(eq(categories.id, id));
  else if (section === "sliders") await db.delete(sliders).where(eq(sliders.id, id));
  else await db.delete(blogPosts).where(eq(blogPosts.id, id));
}

export function isPersistentSection(value: string): value is PersistentSection {
  return persistentSections.includes(value as PersistentSection);
}




