export type Product = {
  slug: string;
  name: string;
  brand: string;
  category: string;
  retailPrice: number;
  wholesalePrice: number;
  moq: number;
  stock: string;
  image: string;
  accent: string;
  description: string;
  specs: string[];
};

export const products: Product[] = [
  { slug: "garmin-fenix-8", name: "Fenix 8 AMOLED", brand: "Garmin", category: "Smart Watches", retailPrice: 119500, wholesalePrice: 112500, moq: 3, stock: "Ready stock", image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=85", accent: "#f2f2f2", description: "Premium multisport GPS smartwatch built for endurance, training and outdoor performance.", specs: ["AMOLED display", "Advanced GPS", "10 ATM water rating", "Up to 16 days battery"] },
  { slug: "dji-mini-4-pro", name: "Mini 4 Pro Fly More", brand: "DJI", category: "Drones", retailPrice: 135000, wholesalePrice: 128000, moq: 2, stock: "Limited stock", image: "https://images.unsplash.com/photo-1507582020474-9a35b7d455d9?auto=format&fit=crop&w=900&q=85", accent: "#f1f3f5", description: "Compact professional camera drone with omnidirectional obstacle sensing and 4K imaging.", specs: ["Under 249 g", "4K/100fps", "Omnidirectional sensing", "34-minute flight time"] },
  { slug: "gopro-hero-13", name: "HERO13 Black", brand: "GoPro", category: "Action Cameras", retailPrice: 54900, wholesalePrice: 51500, moq: 5, stock: "Ready stock", image: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=900&q=85", accent: "#f4f4f4", description: "Flagship action camera for creators, sports and demanding professional production.", specs: ["5.3K video", "HyperSmooth", "Waterproof", "Wi-Fi + Bluetooth"] },
  { slug: "insta360-x4", name: "X4 8K 360 Camera", brand: "Insta360", category: "360 Cameras", retailPrice: 62900, wholesalePrice: 58500, moq: 4, stock: "Ready stock", image: "https://images.unsplash.com/photo-1606986628253-8d27555dfca8?auto=format&fit=crop&w=900&q=85", accent: "#f3f3f5", description: "Immersive 8K 360 camera with invisible selfie stick effects and AI reframing.", specs: ["8K 360 video", "FlowState stabilization", "135-minute runtime", "Waterproof to 10 m"] },
  { slug: "dji-mic-2", name: "Mic 2 Creator Combo", brand: "DJI", category: "Audio Equipment", retailPrice: 47900, wholesalePrice: 44500, moq: 5, stock: "Incoming", image: "https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&w=900&q=85", accent: "#f5f1f1", description: "Intelligent wireless audio system for interviews, production and mobile content creation.", specs: ["32-bit float recording", "Intelligent noise cancelling", "250 m range", "18-hour battery"] },
  { slug: "garmin-inreach-mini-2", name: "inReach Mini 2", brand: "Garmin", category: "Outdoor Navigation", retailPrice: 51900, wholesalePrice: 48000, moq: 4, stock: "Ready stock", image: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=900&q=85", accent: "#f2f5f1", description: "Compact satellite communicator for remote teams, expeditions and outdoor professionals.", specs: ["Two-way messaging", "SOS response", "Location sharing", "14-day battery"] }
];

export const brands = [
  { name: "GARMIN", line: "Performance & navigation", detail: "Smartwatches, outdoor navigation and professional GPS devices." },
  { name: "DJI", line: "Aerial & creator systems", detail: "Drones, stabilizers, action cameras and wireless audio." },
  { name: "GoPro", line: "Action imaging", detail: "Durable cameras and accessories for demanding creators." },
  { name: "Insta360", line: "Immersive capture", detail: "360 cameras and intelligent content-creation tools." }
];

export const money = (value: number) => `৳${value.toLocaleString("en-BD")}`;
