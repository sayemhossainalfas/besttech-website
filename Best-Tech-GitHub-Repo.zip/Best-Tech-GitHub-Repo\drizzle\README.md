# Drizzle migrations

The previous archive contained MySQL-generated migration snapshots. The active schema is now PostgreSQL.

After setting `DATABASE_URL`, generate fresh PostgreSQL migrations with:

```bash
npm run db:generate
```

Then apply them with:

```bash
npm run db:migrate
```
