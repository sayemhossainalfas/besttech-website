"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { Edit3, LoaderCircle, Plus, Search, Trash2, X } from "lucide-react";
import AdminEditorFields, { AdminRecord, AdminReferences } from "./AdminEditorFields";

const labels: Record<string, string> = { sliders:"Slide", products:"Product", categories:"Category", brands:"Brand", blog:"Blog post" };
const persistentSections = new Set(Object.keys(labels));
const emptyReferences: AdminReferences = { brands: [], categories: [] };

async function readJson(response: Response) {
  const body = await response.json().catch(() => ({})) as { error?: string; item?: AdminRecord; items?: AdminRecord[]; urls?: string[] };
  if (!response.ok) throw new Error(body.error || `Request failed with status ${response.status}`);
  return body;
}

async function upload(form: FormData, field: string) {
  const files = form.getAll(field).filter((entry): entry is File => entry instanceof File && entry.size > 0);
  if (!files.length) return [];
  const uploadForm = new FormData(); files.forEach((file) => uploadForm.append("files", file));
  const result = await readJson(await fetch("/api/admin/uploads", { method: "POST", body: uploadForm }));
  return result.urls || [];
}

async function formPayload(form: FormData) {
  const payload: Record<string, unknown> = {};
  form.forEach((value, key) => { if (!(value instanceof File)) payload[key] = value; });
  const [productImages, logo, categoryImage, sliderImage, coverImage, ogImage] = await Promise.all([
    upload(form,"productImages"), upload(form,"logoFile"), upload(form,"categoryImageFile"), upload(form,"sliderImageFile"), upload(form,"coverImageFile"), upload(form,"ogImageFile"),
  ]);
  const existingImages = String(payload.imageUrls || "").split(/\r?\n|,/).map((value)=>value.trim()).filter(Boolean);
  payload.images = [...existingImages, ...productImages]; delete payload.imageUrls;
  if (logo[0]) payload.logoUrl = logo[0];
  if (categoryImage[0]) payload.imageUrl = categoryImage[0];
  if (sliderImage[0]) payload.imageUrl = sliderImage[0];
  if (coverImage[0]) payload.coverImage = coverImage[0];
  if (ogImage[0]) payload.ogImage = ogImage[0];
  payload.tags = String(payload.tagsText || "").split(",").map((value)=>value.trim()).filter(Boolean); delete payload.tagsText;
  payload.faq = [1,2,3,4,5].map((number)=>({question:String(payload[`faq${number}q`]||"").trim(),answer:String(payload[`faq${number}a`]||"").trim()})).filter((entry)=>entry.question && entry.answer);
  ["isFeatured","isTopSelling","isNewArrival","isDeal","isTrending","showOnHome"].forEach((key)=>payload[key]=form.has(key));
  return payload;
}

export default function AdminModule({section,title,description}:{section:string;title:string;description:string}){
  const supported = persistentSections.has(section);
  const [items,setItems]=useState<AdminRecord[]>([]);
  const [references,setReferences]=useState<AdminReferences>(emptyReferences);
  const [editing,setEditing]=useState<AdminRecord|null>(null);
  const [open,setOpen]=useState(false);
  const [query,setQuery]=useState("");
  const [statusFilter,setStatusFilter]=useState("all");
  const [loading,setLoading]=useState(supported);
  const [saving,setSaving]=useState(false);
  const [deletingId,setDeletingId]=useState<number|null>(null);
  const [error,setError]=useState("");
  const [success,setSuccess]=useState("");

  const load = useCallback(async () => {
    if (!supported) return;
    setLoading(true); setError("");
    try {
      const response = await readJson(await fetch(`/api/admin/content/${section}`, { cache: "no-store" }));
      setItems(response.items || []);
      if (section === "products" || section === "categories") {
        const [brandData, categoryData] = await Promise.all([
          readJson(await fetch("/api/admin/content/brands", { cache: "no-store" })),
          readJson(await fetch("/api/admin/content/categories", { cache: "no-store" })),
        ]);
        setReferences({ brands: brandData.items || [], categories: categoryData.items || [] });
      }
    } catch (loadError) { setError(loadError instanceof Error ? loadError.message : "Unable to load database records"); }
    finally { setLoading(false); }
  }, [section,supported]);

  useEffect(()=>{const timer=window.setTimeout(()=>void load(),0);return()=>window.clearTimeout(timer)},[load]);
  useEffect(()=>{const close=(event:KeyboardEvent)=>{if(event.key==="Escape"&&!saving)setOpen(false)};window.addEventListener("keydown",close);return()=>window.removeEventListener("keydown",close)},[saving]);

  const filtered=useMemo(()=>items.filter((item)=>{
    const matchesText=`${item.name} ${item.detail}`.toLowerCase().includes(query.toLowerCase());
    return matchesText && (statusFilter==="all" || item.status.toLowerCase()===statusFilter);
  }),[items,query,statusFilter]);

  function show(item:AdminRecord|null=null){setEditing(item);setError("");setSuccess("");setOpen(true)}

  async function save(event:FormEvent<HTMLFormElement>){
    event.preventDefault(); if (!supported || saving) return;
    setSaving(true); setError(""); setSuccess("");
    try {
      const payload=await formPayload(new FormData(event.currentTarget));
      const url=editing?`/api/admin/content/${section}/${editing.id}`:`/api/admin/content/${section}`;
      const result=await readJson(await fetch(url,{method:editing?"PUT":"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)}));
      if(!result.item) throw new Error("Database saved the request but returned no record");
      setItems((current)=>editing?current.map((item)=>item.id===editing.id?result.item!:item):[result.item!,...current]);
      setOpen(false); setSuccess(`${labels[section]} saved successfully.`);
      if(section==="brands"||section==="categories") await load();
    } catch(saveError){setError(saveError instanceof Error?saveError.message:"Unable to save this record");}
    finally{setSaving(false)}
  }

  async function remove(item:AdminRecord){
    if(!window.confirm(`Delete â€œ${item.name}â€? This cannot be undone.`))return;
    setDeletingId(item.id);setError("");setSuccess("");
    try{await readJson(await fetch(`/api/admin/content/${section}/${item.id}`,{method:"DELETE"}));setItems((current)=>current.filter((record)=>record.id!==item.id));setSuccess(`${labels[section]} deleted.`)}
    catch(deleteError){setError(deleteError instanceof Error?deleteError.message:"Unable to delete this record")}
    finally{setDeletingId(null)}
  }

  return <>
    <div className="admin-heading"><div><h1>{title}</h1><p>{items.length} records Â· {description}</p></div>{supported&&<button className="btn admin-add-btn btn-sm" onClick={()=>show()}><Plus/>Add {labels[section]}</button>}</div>
    {error&&<div className="admin-message error-text" role="alert">{error}<button onClick={()=>setError("")} aria-label="Dismiss error"><X/></button></div>}
    {success&&<div className="admin-message success-text" role="status">{success}<button onClick={()=>setSuccess("")} aria-label="Dismiss message"><X/></button></div>}
    {!supported&&<div className="admin-message error-text">This legacy section has no production CRUD endpoint yet. No demo data is shown.</div>}
    <div className="admin-toolbar"><label><Search/><input value={query} onChange={event=>setQuery(event.target.value)} placeholder={`Search ${title.toLowerCase()}â€¦`}/></label><select aria-label="Filter status" value={statusFilter} onChange={event=>setStatusFilter(event.target.value)}><option value="all">All status</option><option value="active">Active</option><option value="published">Published</option><option value="draft">Draft</option><option value="inactive">Inactive</option></select></div>
    <section className="admin-panel admin-table-panel"><table className="admin-module-table"><thead><tr><th>Name</th><th>Details</th><th>Status</th><th>Actions</th></tr></thead><tbody>{filtered.map(item=><tr key={item.id}><td><b>{item.name}</b></td><td>{item.detail}</td><td><span className={`admin-status status-${item.status.toLowerCase().replaceAll(" ","-")}`}>{item.status}</span></td><td><button aria-label={`Edit ${item.name}`} onClick={()=>show(item)}><Edit3/></button><button aria-label={`Delete ${item.name}`} className="delete" disabled={deletingId===item.id} onClick={()=>void remove(item)}>{deletingId===item.id?<LoaderCircle className="spin"/>:<Trash2/>}</button></td></tr>)}</tbody></table>{loading&&<div className="admin-empty"><LoaderCircle className="spin"/> Loading database recordsâ€¦</div>}{!loading&&!filtered.length&&<div className="admin-empty">{supported?"No matching database records found.":"No records available."}</div>}</section>
    {open&&<div className="admin-modal-backdrop" onMouseDown={event=>event.target===event.currentTarget&&!saving&&setOpen(false)}><form className={`admin-modal admin-modal-${section}`} onSubmit={save} role="dialog" aria-modal="true" aria-label={`${editing?"Edit":"Add"} ${labels[section]}`}><header><h2>{editing?"Edit":"Add"} {labels[section]}</h2><button type="button" disabled={saving} onClick={()=>setOpen(false)} aria-label="Close dialog"><X/></button></header><div className="admin-modal-body"><AdminEditorFields section={section} item={editing} references={references}/>{error&&<div className="admin-message error-text" role="alert">{error}</div>}</div><footer><button type="button" className="btn btn-ghost" disabled={saving} onClick={()=>setOpen(false)}>Cancel</button><button className="btn admin-add-btn" disabled={saving}>{saving?<><LoaderCircle className="spin"/> Savingâ€¦</>:"Save changes"}</button></footer></form></div>}
  </>;
}


