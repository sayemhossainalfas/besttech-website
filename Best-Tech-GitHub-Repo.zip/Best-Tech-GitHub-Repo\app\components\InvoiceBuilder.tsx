"use client";

import Image from "next/image";
import { CheckCircle2, Download, FilePlus2, Plus, Printer, ReceiptText, Save, Trash2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

type InvoiceItem = { id: number; name: string; sku: string; quantity: number; unitPrice: number };
type SavedInvoice = {
  invoiceNo: string;
  issueDate: string;
  dueDate: string;
  paymentMethod: string;
  customerName: string;
  customerMobile: string;
  customerAddress: string;
  notes: string;
  discount: number;
  deliveryCharge: number;
  paidAmount: number;
  items: InvoiceItem[];
  savedAt: string;
};

const office = "Level-05, Rajlaxmi Complex, Uttara, Dhaka 1230";
const mobile = "+880 1674-603445";
const storageKey = "best-tech-saved-invoices";

function money(value: number) {
  return `BDT ${Math.max(0, value).toLocaleString("en-BD", { maximumFractionDigits: 2 })}`;
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function invoiceNumberFromDate(date = new Date(), index = 1) {
  const stamp = date.toISOString().slice(2, 10).replaceAll("-", "");
  return `BT-INV-${stamp}-${String(index).padStart(3, "0")}`;
}

const blankItem = (): InvoiceItem => ({ id: Date.now(), name: "", sku: "", quantity: 1, unitPrice: 0 });

export default function InvoiceBuilder() {
  const [invoiceNo, setInvoiceNo] = useState(invoiceNumberFromDate());
  const [issueDate, setIssueDate] = useState(today());
  const [dueDate, setDueDate] = useState(today());
  const [paymentMethod, setPaymentMethod] = useState("Cash / COD");
  const [customerName, setCustomerName] = useState("Walk-in Customer");
  const [customerMobile, setCustomerMobile] = useState("");
  const [customerAddress, setCustomerAddress] = useState("");
  const [notes, setNotes] = useState("Thank you for shopping with Best Tech.");
  const [discount, setDiscount] = useState(0);
  const [deliveryCharge, setDeliveryCharge] = useState(0);
  const [paidAmount, setPaidAmount] = useState(0);
  const [items, setItems] = useState<InvoiceItem[]>([{ id: 1, name: "Garmin Fenix 8 AMOLED", sku: "BT-GAR-FENIX8", quantity: 1, unitPrice: 119500 }]);
  const [savedInvoices, setSavedInvoices] = useState<SavedInvoice[]>([]);
  const [message, setMessage] = useState("");

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(storageKey);
      if (stored) setSavedInvoices(JSON.parse(stored) as SavedInvoice[]);
    } catch {
      setSavedInvoices([]);
    }
  }, []);

  const totals = useMemo(() => {
    const subtotal = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
    const total = Math.max(0, subtotal - discount + deliveryCharge);
    const due = Math.max(0, total - paidAmount);
    return { subtotal, total, due };
  }, [deliveryCharge, discount, items, paidAmount]);

  const invoice = useMemo<SavedInvoice>(() => ({
    invoiceNo: invoiceNo.trim() || invoiceNumberFromDate(),
    issueDate,
    dueDate,
    paymentMethod,
    customerName: customerName.trim() || "Walk-in Customer",
    customerMobile,
    customerAddress,
    notes,
    discount,
    deliveryCharge,
    paidAmount,
    items: items.map((item) => ({ ...item, quantity: Math.max(1, item.quantity), unitPrice: Math.max(0, item.unitPrice) })),
    savedAt: new Date().toISOString(),
  }), [customerAddress, customerMobile, customerName, deliveryCharge, discount, dueDate, invoiceNo, issueDate, items, notes, paidAmount, paymentMethod]);

  function updateItem(id: number, patch: Partial<InvoiceItem>) {
    setItems((current) => current.map((item) => item.id === id ? { ...item, ...patch } : item));
  }

  function addItem() {
    setItems((current) => [...current, blankItem()]);
  }

  function removeItem(id: number) {
    setItems((current) => current.length === 1 ? current : current.filter((item) => item.id !== id));
  }

  function saveInvoice() {
    if (!invoice.items.some((item) => item.name.trim())) {
      setMessage("Add at least one product before saving.");
      return false;
    }

    const next = [invoice, ...savedInvoices.filter((saved) => saved.invoiceNo !== invoice.invoiceNo)].slice(0, 25);
    setSavedInvoices(next);
    window.localStorage.setItem(storageKey, JSON.stringify(next));
    setMessage(`Saved ${invoice.invoiceNo}`);
    return true;
  }

  function loadInvoice(saved: SavedInvoice) {
    setInvoiceNo(saved.invoiceNo);
    setIssueDate(saved.issueDate);
    setDueDate(saved.dueDate);
    setPaymentMethod(saved.paymentMethod);
    setCustomerName(saved.customerName);
    setCustomerMobile(saved.customerMobile);
    setCustomerAddress(saved.customerAddress);
    setNotes(saved.notes);
    setDiscount(saved.discount);
    setDeliveryCharge(saved.deliveryCharge);
    setPaidAmount(saved.paidAmount);
    setItems(saved.items.length ? saved.items : [blankItem()]);
    setMessage(`Loaded ${saved.invoiceNo}`);
  }

  function deleteInvoice(invoiceNumber: string) {
    const next = savedInvoices.filter((saved) => saved.invoiceNo !== invoiceNumber);
    setSavedInvoices(next);
    window.localStorage.setItem(storageKey, JSON.stringify(next));
    setMessage(`Deleted ${invoiceNumber}`);
  }

  function newInvoice() {
    const nextNumber = invoiceNumberFromDate(new Date(), savedInvoices.length + 1);
    setInvoiceNo(nextNumber);
    setIssueDate(today());
    setDueDate(today());
    setPaymentMethod("Cash / COD");
    setCustomerName("Walk-in Customer");
    setCustomerMobile("");
    setCustomerAddress("");
    setNotes("Thank you for shopping with Best Tech.");
    setDiscount(0);
    setDeliveryCharge(0);
    setPaidAmount(0);
    setItems([blankItem()]);
    setMessage("New invoice ready");
  }

  function printInvoice() {
    if (!saveInvoice()) return;
    window.setTimeout(() => window.print(), 120);
  }

  return (
    <>
      <div className="admin-heading invoice-heading no-print">
        <div>
          <h1>Invoice creator</h1>
          <p>Create, save, and print branded Best Tech invoices.</p>
        </div>
        <div className="invoice-heading-actions">
          <button className="btn btn-ghost btn-sm" type="button" onClick={newInvoice}><FilePlus2 /> New</button>
          <button className="btn btn-ghost btn-sm" type="button" onClick={saveInvoice}><Save /> Save</button>
          <button className="btn btn-ghost btn-sm" type="button" onClick={printInvoice}><Download /> Save PDF</button>
          <button className="btn btn-primary btn-sm" type="button" onClick={printInvoice}><Printer /> Print</button>
        </div>
      </div>

      {message && <div className="admin-message invoice-message no-print" role="status"><CheckCircle2 />{message}<button type="button" onClick={() => setMessage("")} aria-label="Dismiss message">x</button></div>}

      <div className="invoice-workspace">
        <section className="admin-panel invoice-controls no-print">
          <h2><ReceiptText /> Invoice details</h2>
          <div className="form-grid">
            <div className="field"><label>Invoice number</label><input value={invoiceNo} onChange={(event) => setInvoiceNo(event.target.value)} /></div>
            <div className="field"><label>Issue date</label><input type="date" value={issueDate} onChange={(event) => setIssueDate(event.target.value)} /></div>
            <div className="field"><label>Due date</label><input type="date" value={dueDate} onChange={(event) => setDueDate(event.target.value)} /></div>
            <div className="field"><label>Payment method</label><select value={paymentMethod} onChange={(event) => setPaymentMethod(event.target.value)}><option>Cash / COD</option><option>bKash</option><option>Nagad</option><option>Bank transfer</option><option>Card / SSLCommerz</option></select></div>
            <div className="field"><label>Customer name</label><input value={customerName} onChange={(event) => setCustomerName(event.target.value)} /></div>
            <div className="field"><label>Customer mobile</label><input value={customerMobile} onChange={(event) => setCustomerMobile(event.target.value)} placeholder="01XXXXXXXXX" /></div>
            <div className="field full"><label>Customer address</label><textarea value={customerAddress} onChange={(event) => setCustomerAddress(event.target.value)} placeholder="House, road, area, district" /></div>
          </div>

          <div className="invoice-items-editor">
            <div className="invoice-items-title"><h2>Line items</h2><button className="btn admin-add-btn btn-sm" type="button" onClick={addItem}><Plus /> Add item</button></div>
            {items.map((item) => <div className="invoice-item-row" key={item.id}><div className="field"><label>Product</label><input value={item.name} onChange={(event) => updateItem(item.id, { name: event.target.value })} /></div><div className="field"><label>SKU</label><input value={item.sku} onChange={(event) => updateItem(item.id, { sku: event.target.value })} /></div><div className="field"><label>Qty</label><input type="number" min={1} value={item.quantity} onChange={(event) => updateItem(item.id, { quantity: Number(event.target.value) || 1 })} /></div><div className="field"><label>Unit price</label><input type="number" min={0} value={item.unitPrice} onChange={(event) => updateItem(item.id, { unitPrice: Number(event.target.value) || 0 })} /></div><button className="invoice-remove" type="button" onClick={() => removeItem(item.id)} aria-label={`Remove ${item.name || "item"}`}><Trash2 /></button></div>)}
          </div>

          <div className="form-grid invoice-adjustments">
            <div className="field"><label>Discount</label><input type="number" min={0} value={discount} onChange={(event) => setDiscount(Number(event.target.value) || 0)} /></div>
            <div className="field"><label>Delivery charge</label><input type="number" min={0} value={deliveryCharge} onChange={(event) => setDeliveryCharge(Number(event.target.value) || 0)} /></div>
            <div className="field"><label>Paid amount</label><input type="number" min={0} value={paidAmount} onChange={(event) => setPaidAmount(Number(event.target.value) || 0)} /></div>
            <div className="field full"><label>Notes</label><textarea value={notes} onChange={(event) => setNotes(event.target.value)} /></div>
          </div>

          <section className="invoice-saved-list">
            <h2>Saved invoices</h2>
            {savedInvoices.length ? savedInvoices.map((saved) => <div className="invoice-saved-row" key={saved.invoiceNo}><button type="button" onClick={() => loadInvoice(saved)}><strong>{saved.invoiceNo}</strong><span>{saved.customerName} - {saved.issueDate}</span></button><button type="button" className="invoice-delete-saved" onClick={() => deleteInvoice(saved.invoiceNo)} aria-label={`Delete ${saved.invoiceNo}`}><Trash2 /></button></div>) : <p className="muted">No saved invoices yet.</p>}
          </section>
        </section>

        <section className="invoice-preview-panel">
          <div className="invoice-print-area">
            <div className="invoice-sheet">
              <header className="invoice-brand-row"><div><Image src="/website-logo.png" width={210} height={50} alt="Best Tech" priority /><p>{office}<br />Mobile / WhatsApp: {mobile}</p></div><div className="invoice-title-block"><span>Invoice</span><strong>{invoice.invoiceNo}</strong></div></header>
              <div className="invoice-meta-grid"><div><span>Bill to</span><strong>{invoice.customerName}</strong><p>{invoice.customerMobile || "Customer mobile"}<br />{invoice.customerAddress || "Customer address"}</p></div><div><span>Issue date</span><strong>{invoice.issueDate}</strong><span>Due date</span><strong>{invoice.dueDate}</strong><span>Payment</span><strong>{invoice.paymentMethod}</strong></div></div>
              <table className="invoice-table"><thead><tr><th>Item</th><th>SKU</th><th>Qty</th><th>Unit</th><th>Total</th></tr></thead><tbody>{invoice.items.map((item) => <tr key={item.id}><td>{item.name || "Product name"}</td><td>{item.sku || "-"}</td><td>{item.quantity}</td><td>{money(item.unitPrice)}</td><td>{money(item.quantity * item.unitPrice)}</td></tr>)}</tbody></table>
              <div className="invoice-bottom-grid"><div className="invoice-notes"><span>Notes</span><p>{invoice.notes}</p></div><div className="invoice-totals"><p><span>Subtotal</span><strong>{money(totals.subtotal)}</strong></p><p><span>Discount</span><strong>- {money(invoice.discount)}</strong></p><p><span>Delivery</span><strong>{money(invoice.deliveryCharge)}</strong></p><p><span>Paid</span><strong>- {money(invoice.paidAmount)}</strong></p><p className="invoice-grand"><span>Due total</span><strong>{money(totals.due)}</strong></p></div></div>
              <footer className="invoice-footer-row"><span>Authorized signature</span><strong>Best Tech</strong></footer>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

