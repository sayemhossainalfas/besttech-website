import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";

export type SessionUser = { id: number; name: string; email: string; role: "customer" | "wholesaler" | "admin"; wholesaleStatus: "none" | "pending" | "approved" | "rejected" };
const COOKIE_NAME = "we_session";

function secret() {
  const value = process.env.SESSION_SECRET;
  if (!value || value.length < 32) throw new Error("SESSION_SECRET must be at least 32 characters");
  return new TextEncoder().encode(value);
}

export async function createSession(user: SessionUser) {
  const token = await new SignJWT(user).setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("7d").sign(secret());
  const store = await cookies();
  store.set(COOKIE_NAME, token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 7 });
}

export async function getSession(): Promise<SessionUser | null> {
  const token = (await cookies()).get(COOKIE_NAME)?.value;
  if (!token) return null;
  try { return (await jwtVerify(token, secret())).payload as unknown as SessionUser; } catch { return null; }
}

export async function destroySession() { (await cookies()).delete(COOKIE_NAME); }
export async function requireAdmin() { const session = await getSession(); if (!session || session.role !== "admin") throw new Error("UNAUTHORIZED"); return session; }


