"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { FileText, FolderTree, Handshake, ImageIcon, LayoutDashboard, LogOut, Menu, Package, ReceiptText, Settings, ShoppingCart, Tags, Users, X } from "lucide-react";
import { useState } from "react";

const nav = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/sliders", label: "Homepage slider", icon: ImageIcon },
  { href: "/admin/products", label: "Products", icon: Package },
  { href: "/admin/categories", label: "Categories", icon: FolderTree },
  { href: "/admin/brands", label: "Brands", icon: Tags },
  { href: "/admin/customers", label: "Customers", icon: Users },
  { href: "/admin/orders", label: "Orders", icon: ShoppingCart },
  { href: "/admin/invoices", label: "Invoices", icon: ReceiptText },
  { href: "/admin/wholesalers", label: "Wholesale requests", icon: Handshake },
  { href: "/admin/blog", label: "Blog posts", icon: FileText },
  { href: "/admin/settings", label: "Settings", icon: Settings },
];

export default function AdminShell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const [open, setOpen] = useState(false);

  return <div className="admin-app">
    <aside className={`admin-sidebar ${open ? "open" : ""}`}>
      <div className="admin-brand"><Image src="/falcon-icon.png" width={58} height={44} alt="Best Tech icon" /><span><b>Best</b><small>Tech</small></span><button onClick={() => setOpen(false)} aria-label="Close navigation"><X /></button></div>
      <nav>{nav.map(item => { const Icon = item.icon; const active = item.href === "/admin" ? path === item.href : path.startsWith(item.href); return <Link className={active ? "active" : ""} href={item.href} key={item.href} onClick={() => setOpen(false)}><Icon />{item.label}</Link>; })}</nav>
      <Link className="admin-logout" href="/"><LogOut />Back to website</Link>
    </aside>
    <div className="admin-main"><header className="admin-topbar"><button className="admin-menu" onClick={() => setOpen(true)} aria-label="Open navigation"><Menu /></button><div className="admin-search">Search dashboard, orders, products...</div><div className="admin-user"><span><b>Administrator</b><small>Store manager</small></span><i>A</i></div></header><main className="admin-content">{children}</main></div>
  </div>;
}

