import { boolean, decimal, index, integer, jsonb, pgEnum, pgTable, serial, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/pg-core";

export const userRole = pgEnum("role", ["customer", "wholesaler", "admin"]);
export const wholesaleStatus = pgEnum("wholesale_status", ["none", "pending", "approved", "rejected"]);
export const applicationStatus = pgEnum("application_status", ["pending", "approved", "rejected"]);
export const productAvailability = pgEnum("availability", ["in_stock", "preorder", "out_of_stock"]);
export const productStatus = pgEnum("product_status", ["draft", "published", "disabled"]);
export const orderType = pgEnum("order_type", ["retail", "wholesale"]);
export const orderStatus = pgEnum("order_status", ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]);
export const paymentMethod = pgEnum("payment_method", ["cod", "bank_transfer", "bkash", "nagad", "sslcommerz"]);
export const paymentStatus = pgEnum("payment_status", ["unpaid", "pending", "paid", "failed", "refunded"]);
export const blogStatus = pgEnum("blog_status", ["draft", "published"]);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 190 }).notNull(),
  mobile: varchar("mobile", { length: 30 }).notNull(),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  role: userRole("role").default("customer").notNull(),
  wholesaleStatus: wholesaleStatus("wholesale_status").default("none").notNull(),
  address: text("address"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => [uniqueIndex("users_email_unique").on(table.email), uniqueIndex("users_mobile_unique").on(table.mobile)]);

export const wholesaleApplications = pgTable("wholesale_applications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  businessName: varchar("business_name", { length: 190 }).notNull(),
  businessType: varchar("business_type", { length: 100 }).notNull(),
  tradeLicense: varchar("trade_license", { length: 120 }),
  businessAddress: text("business_address").notNull(),
  expectedMonthlyPurchase: varchar("expected_monthly_purchase", { length: 80 }),
  notes: text("notes"),
  status: applicationStatus("status").default("pending").notNull(),
  reviewedBy: integer("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at", { mode: "date" }),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => [index("wholesale_user_idx").on(table.userId), index("wholesale_status_idx").on(table.status)]);

export const brands = pgTable("brands", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  slug: varchar("slug", { length: 140 }).notNull(),
  logoUrl: varchar("logo_url", { length: 500 }),
  description: text("description"),
  seoTitle: varchar("seo_title", { length: 190 }),
  seoDescription: varchar("seo_description", { length: 300 }),
  isActive: boolean("is_active").default(true).notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => [uniqueIndex("brands_slug_unique").on(table.slug)]);

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 140 }).notNull(),
  slug: varchar("slug", { length: 160 }).notNull(),
  imageUrl: varchar("image_url", { length: 500 }),
  icon: varchar("icon", { length: 80 }),
  description: text("description"),
  parentId: integer("parent_id"),
  seoTitle: varchar("seo_title", { length: 190 }),
  seoDescription: varchar("seo_description", { length: 300 }),
  isActive: boolean("is_active").default(true).notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => [uniqueIndex("categories_slug_unique").on(table.slug)]);

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 220 }).notNull(),
  slug: varchar("slug", { length: 240 }).notNull(),
  sku: varchar("sku", { length: 100 }).notNull(),
  brandId: integer("brand_id").references(() => brands.id),
  categoryId: integer("category_id").references(() => categories.id),
  shortDescription: text("short_description"),
  description: text("description"),
  retailPrice: decimal("retail_price", { precision: 12, scale: 2 }).notNull(),
  salePrice: decimal("sale_price", { precision: 12, scale: 2 }),
  wholesalePrice: decimal("wholesale_price", { precision: 12, scale: 2 }),
  costPrice: decimal("cost_price", { precision: 12, scale: 2 }),
  minimumWholesaleQty: integer("minimum_wholesale_qty").default(1).notNull(),
  stock: integer("stock").default(0).notNull(),
  lowStockThreshold: integer("low_stock_threshold").default(5).notNull(),
  images: jsonb("images").$type<string[]>().notNull(),
  specifications: jsonb("specifications").$type<Record<string, string>>(),
  availability: productAvailability("availability").default("in_stock").notNull(),
  weight: varchar("weight", { length: 80 }),
  dimensions: varchar("dimensions", { length: 120 }),
  warranty: text("warranty"),
  shippingInfo: text("shipping_info"),
  returnPolicy: text("return_policy"),
  packageIncludes: text("package_includes"),
  isFeatured: boolean("is_featured").default(false).notNull(),
  isTopSelling: boolean("is_top_selling").default(false).notNull(),
  isNewArrival: boolean("is_new_arrival").default(false).notNull(),
  isDeal: boolean("is_deal").default(false).notNull(),
  isTrending: boolean("is_trending").default(false).notNull(),
  showOnHome: boolean("show_on_home").default(false).notNull(),
  status: productStatus("status").default("published").notNull(),
  isPublished: boolean("is_published").default(true).notNull(),
  seoTitle: varchar("seo_title", { length: 190 }),
  metaKeywords: varchar("meta_keywords", { length: 500 }),
  seoDescription: varchar("seo_description", { length: 300 }),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => [uniqueIndex("products_slug_unique").on(table.slug), uniqueIndex("products_sku_unique").on(table.sku), index("products_featured_idx").on(table.isFeatured)]);

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: varchar("order_number", { length: 40 }).notNull(),
  userId: integer("user_id").references(() => users.id),
  customerName: varchar("customer_name", { length: 120 }).notNull(),
  mobile: varchar("mobile", { length: 30 }).notNull(),
  email: varchar("email", { length: 190 }),
  deliveryAddress: text("delivery_address").notNull(),
  orderType: orderType("order_type").default("retail").notNull(),
  status: orderStatus("status").default("pending").notNull(),
  paymentMethod: paymentMethod("payment_method").notNull(),
  paymentStatus: paymentStatus("payment_status").default("unpaid").notNull(),
  subtotal: decimal("subtotal", { precision: 12, scale: 2 }).notNull(),
  deliveryFee: decimal("delivery_fee", { precision: 12, scale: 2 }).default("0").notNull(),
  total: decimal("total", { precision: 12, scale: 2 }).notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => [uniqueIndex("orders_number_unique").on(table.orderNumber), index("orders_user_idx").on(table.userId), index("orders_status_idx").on(table.status)]);

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull().references(() => orders.id),
  productId: integer("product_id").notNull().references(() => products.id),
  productName: varchar("product_name", { length: 220 }).notNull(),
  sku: varchar("sku", { length: 100 }).notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: decimal("unit_price", { precision: 12, scale: 2 }).notNull(),
  total: decimal("total", { precision: 12, scale: 2 }).notNull(),
}, (table) => [index("order_items_order_idx").on(table.orderId)]);

export const sliders = pgTable("sliders", {
  id: serial("id").primaryKey(),
  eyebrow: varchar("eyebrow", { length: 120 }),
  title: varchar("title", { length: 220 }).notNull(),
  description: text("description"),
  imageUrl: varchar("image_url", { length: 500 }).notNull(),
  buttonLabel: varchar("button_label", { length: 80 }),
  buttonUrl: varchar("button_url", { length: 255 }),
  secondaryButtonLabel: varchar("secondary_button_label", { length: 80 }),
  secondaryButtonUrl: varchar("secondary_button_url", { length: 255 }),
  imagePosition: varchar("image_position", { length: 80 }).default("center").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
});

export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 240 }).notNull(),
  slug: varchar("slug", { length: 260 }).notNull(),
  excerpt: text("excerpt"),
  content: text("content").notNull(),
  coverImage: varchar("cover_image", { length: 500 }),
  coverAlt: varchar("cover_alt", { length: 240 }),
  authorName: varchar("author_name", { length: 140 }),
  authorId: integer("author_id").notNull().references(() => users.id),
  category: varchar("category", { length: 120 }),
  tags: jsonb("tags").$type<string[]>(),
  status: blogStatus("status").default("draft").notNull(),
  seoTitle: varchar("seo_title", { length: 190 }),
  metaKeywords: varchar("meta_keywords", { length: 500 }),
  seoDescription: varchar("seo_description", { length: 300 }),
  canonicalUrl: varchar("canonical_url", { length: 500 }),
  ogTitle: varchar("og_title", { length: 240 }),
  ogDescription: varchar("og_description", { length: 500 }),
  ogImage: varchar("og_image", { length: 500 }),
  faq: jsonb("faq").$type<Array<{ question: string; answer: string }>>(),
  publishedAt: timestamp("published_at", { mode: "date" }),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => [uniqueIndex("blog_slug_unique").on(table.slug), index("blog_status_idx").on(table.status)]);


