export const blogPosts=[
 {slug:"choosing-action-camera-bangladesh",title:"How to Choose an Action Camera in Bangladesh",excerpt:"A practical comparison of stabilization, resolution, durability, battery life, and accessories for creators.",date:"June 12, 2026",category:"Buying guide",image:"https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=1000&q=85"},
 {slug:"drone-business-guide",title:"A Business Buyerâ€™s Guide to Professional Drones",excerpt:"What retailers and corporate teams should consider before investing in modern aerial imaging systems.",date:"June 5, 2026",category:"Business insights",image:"https://images.unsplash.com/photo-1473968512647-3e447244af8f?auto=format&fit=crop&w=1000&q=85"},
 {slug:"garmin-wearables-retail",title:"Why Premium Wearables Are Growing in Retail",excerpt:"Understanding demand for fitness, navigation, and outdoor technology in the Bangladesh market.",date:"May 28, 2026",category:"Market insights",image:"https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=1000&q=85"}
];


