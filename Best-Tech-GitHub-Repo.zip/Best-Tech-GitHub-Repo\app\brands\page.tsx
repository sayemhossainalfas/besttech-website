import Link from "next/link";
import { ArrowRight } from "lucide-react";
import PageHero from "../components/PageHero";
import { getPublicBrands } from "@/lib/public-content";
export const dynamic="force-dynamic";
export const revalidate=0;
export default async function Brands(){const brands=await getPublicBrands();return <><PageHero title="Global brands, local distribution" description="A focused portfolio of technology brands chosen for performance, demand, and long-term market value."/><section className="section-sm"><div className="shell grid two">{brands.map((brand,index)=><article key={brand.id||brand.name} className="category-card" style={{background:index%2?"#ede9e2":"var(--ink)",color:index%2?"var(--ink)":"white",minHeight:330}}><span className="num">{String(index+1).padStart(2,"0")}</span><div><div className="eyebrow">{brand.line}</div><h2 className="title">{brand.name}</h2><p style={{maxWidth:400,lineHeight:1.7,opacity:.75}}>{brand.detail}</p><Link className={index%2?"btn btn-dark":"btn btn-primary"} href={`/catalog?brand=${brand.slug||brand.name}`}>View products <ArrowRight size={16}/></Link></div></article>)}</div></section></>}


