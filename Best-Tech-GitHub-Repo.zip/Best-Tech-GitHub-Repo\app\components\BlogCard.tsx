import Link from "next/link";
import { ArrowRight } from "lucide-react";
import type { PublicBlogPost } from "@/lib/public-content";
import SafeImage from "./SafeImage";

export default function BlogCard({ post }: { post: PublicBlogPost }) {
  return <article className="blog-card store-blog-card"><Link className="blog-image store-blog-media" href={`/blog/${post.slug}`} aria-label={`Read ${post.title}`}><SafeImage src={post.image} alt={post.coverAlt || post.title} sizes="(max-width: 700px) 100vw, 33vw"/></Link><div className="blog-card-body"><span>{post.category} Â· {post.date}</span><h3><Link href={`/blog/${post.slug}`}>{post.title}</Link></h3><p>{post.excerpt}</p><Link className="blog-link" href={`/blog/${post.slug}`}>Read article <ArrowRight size={14} aria-hidden="true"/></Link></div></article>;
}


