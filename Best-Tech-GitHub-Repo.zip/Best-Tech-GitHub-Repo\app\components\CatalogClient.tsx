"use client";

import { useMemo, useState } from "react";
import { SlidersHorizontal } from "lucide-react";
import type { PublicBrand, PublicCategory, PublicProduct } from "@/lib/public-content";
import ProductCard from "./ProductCard";

function slugify(value: string) { return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""); }

export default function CatalogClient({ products, brands, categories, initialCategory, initialBrand }: { products: PublicProduct[]; brands: PublicBrand[]; categories: PublicCategory[]; initialCategory: string; initialBrand: string }) {
  const brandNames = ["All", ...Array.from(new Set(brands.map((item) => item.name)))];
  const categoryNames = ["All", ...Array.from(new Set(categories.map((item) => item.name)))];
  const prices = products.map((product) => product.retailPrice || 0);
  const maxPrice = Math.max(...prices, 100000);
  const [brand, setBrand] = useState(brandNames.find((value) => slugify(value) === initialBrand) || initialBrand || "All");
  const [category, setCategory] = useState(categoryNames.find((value) => slugify(value) === initialCategory) || initialCategory || "All");
  const [priceLimit, setPriceLimit] = useState(maxPrice);
  const [sort, setSort] = useState("featured");

  const list = useMemo(() => products.filter((product) => (brand === "All" || product.brand === brand) && (category === "All" || product.category === category) && Number(product.retailPrice || 0) <= priceLimit).sort((a,b) => sort === "price" ? a.retailPrice-b.retailPrice : sort === "name" ? a.name.localeCompare(b.name) : Number(Boolean(b.isFeatured))-Number(Boolean(a.isFeatured))), [products, brand, category, priceLimit, sort]);

  return <><section className="catalog-intro"><div className="shell"><div className="eyebrow">Shop</div><h1>All Products</h1><p>{products.length} products available</p></div></section><section className="catalog-page-clean"><div className="shell mobile-catalog-controls"><label>Brand<select value={brand} onChange={(event)=>setBrand(event.target.value)}>{brandNames.map(value=><option key={value}>{value}</option>)}</select></label><label>Category<select value={category} onChange={(event)=>setCategory(event.target.value)}>{categoryNames.map(value=><option key={value}>{value}</option>)}</select></label></div><div className="shell catalog-layout catalog-layout-fixed"><aside className="filters catalog-sticky-filter"><h2><SlidersHorizontal aria-hidden="true"/> Filters</h2><div className="filter-group"><strong>Brand</strong>{brandNames.map((value)=><label className="check" key={value}><input type="radio" name="brand" checked={brand===value} onChange={()=>setBrand(value)}/>{value}</label>)}</div><div className="filter-group"><strong>Category</strong>{categoryNames.map((value)=><label className="check" key={value}><input type="radio" name="category" checked={category===value} onChange={()=>setCategory(value)}/>{value}</label>)}</div><div className="filter-group"><strong>Price range</strong><div className="price-range-row"><span>à§³0</span><span>à§³{priceLimit.toLocaleString("en-BD")}</span></div><input aria-label="Maximum price" type="range" min={0} max={maxPrice} step={500} value={priceLimit} onChange={(event)=>setPriceLimit(Number(event.target.value))}/></div></aside><div className="catalog-products"><div className="catalog-tools"><span className="muted">Showing {list.length} results</span><select className="select" aria-label="Sort products" value={sort} onChange={(event)=>setSort(event.target.value)}><option value="featured">Sort: Featured</option><option value="price">Price: low to high</option><option value="name">Name: A to Z</option></select></div><div className="product-grid catalog-grid-four">{list.map((product)=><ProductCard p={product} key={product.slug}/>)}</div>{!list.length&&<div className="form-card empty-state">No published products match these filters.</div>}</div></div></section></>;
}


