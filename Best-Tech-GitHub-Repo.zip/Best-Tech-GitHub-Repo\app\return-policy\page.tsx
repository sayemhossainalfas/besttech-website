import LegalPage from "../components/LegalPage";
export const metadata={title:"Return & Refund Policy"};
export default function Returns(){return <LegalPage title="Return & refund policy" intro="Clear conditions for reporting delivery issues, requesting returns, and receiving eligible refunds." sections={[
 {title:"Inspecting your delivery",paragraphs:["Please inspect the parcel and product condition at delivery where possible. Report a wrong, missing, physically damaged, or dead-on-arrival product within 48 hours with the order number, unboxing evidence, product images, and packaging."]},
 {title:"Return eligibility",paragraphs:["A return may be accepted when the supplied item is materially different from the confirmed order, arrives damaged, is verified as defective on arrival, or otherwise qualifies under applicable consumer rights.","The product must include the original box, serial labels, accessories, manuals, free items, and proof of purchase. Serial numbers and warranty labels must be intact."]},
 {title:"Items normally not returnable",paragraphs:["Change-of-mind returns, used or activated devices, products with removed seals where hygiene or licensing applies, damaged packaging, missing accessories, software or digital codes, and damage caused by misuse, installation, impact, moisture, voltage, or unauthorised repair are normally not eligible unless required by law."]},
 {title:"Warranty claims",paragraphs:["Faults arising after the initial delivery inspection period are handled under the applicable manufacturer, supplier, or service warranty. Warranty processing time and remedy depend on inspection and the relevant warranty terms."]},
 {title:"Refunds",paragraphs:["Approved refunds are issued after inspection through the original payment method where available. Banking and gateway processing times may vary. Delivery charges may be non-refundable unless the return results from our error or a qualifying defect."]},
 {title:"How to request",paragraphs:["Contact +880 1674-603445 or +880 1674-603445, or email support@besttech.com.bd before returning any item. Products sent without an approved return reference may not be accepted."]}
 ]}/>}


