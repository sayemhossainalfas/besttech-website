import { and, asc, desc, eq } from "drizzle-orm";
import { existsSync } from "node:fs";
import path from "node:path";
import { blogPosts as fallbackPosts } from "@/app/blog-data";
import {
  brands as fallbackBrands,
  products as fallbackProducts,
  type Product,
} from "@/app/data";
import { getDb } from "./db";
import { blogPosts, brands, categories, products, sliders } from "./db/schema";

export type PublicProduct = Product & {
  id?: number;
  images?: string[];
  isFeatured?: boolean;
  isTopSelling?: boolean;
  showOnHome?: boolean;
};

export type PublicBrand = {
  id?: number;
  name: string;
  slug?: string;
  line: string;
  detail: string;
  logoUrl?: string;
};

export type PublicCategory = {
  id?: number;
  name: string;
  slug: string;
  description: string;
  imageUrl?: string;
  icon?: string;
};

export type PublicSlide = {
  id?: number;
  eyebrow: string;
  title: string;
  copy: string;
  image: string;
  position: string;
  primary: string;
  href: string;
  secondary: string;
  secondaryHref: string;
};

export type PublicBlogPost = {
  id?: number;
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  category: string;
  image: string;
  coverAlt?: string;
  author: string;
  content: string;
  seoTitle?: string;
  seoDescription?: string;
  faq?: Array<{ question: string; answer: string }>;
};

const fallbackSlides: PublicSlide[] = [
  {
    eyebrow: "B2B electronics distribution",
    title: "Global technology. Built for Bangladesh.",
    copy: "Authentic electronics, dependable wholesale supply, and partner support for retailers, resellers, and corporate buyers.",
    image:
      "https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&w=2000&q=90",
    position: "center",
    primary: "Explore wholesale catalog",
    href: "/catalog",
    secondary: "Become a dealer",
    secondaryHref: "/dealer",
  },
  {
    eyebrow: "Professional aerial systems",
    title: "Capture more. Move business forward.",
    copy: "Trade-ready DJI drones, stabilizers, and imaging systems for modern retailers and professional creators.",
    image:
      "https://images.unsplash.com/photo-1473968512647-3e447244af8f?auto=format&fit=crop&w=2000&q=90",
    position: "center 43%",
    primary: "Shop DJI wholesale",
    href: "/catalog",
    secondary: "Request a quote",
    secondaryHref: "/inquiry",
  },
  {
    eyebrow: "Wearables & outdoor technology",
    title: "Performance built for every frontier.",
    copy: "Premium Garmin wearables and navigation technology backed by reliable B2B supply across Bangladesh.",
    image:
      "https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?auto=format&fit=crop&w=2000&q=90",
    position: "center",
    primary: "Discover Garmin",
    href: "/catalog",
    secondary: "Wholesale inquiry",
    secondaryHref: "/inquiry",
  },
];

function databaseConfigured() {
  return Boolean(process.env.DATABASE_URL);
}

function cleanImages(images: unknown): string[] {
  if (!Array.isArray(images)) return ["/icon.png"];

  const cleaned = images
    .map((image) => String(image || "").trim())
    .filter(Boolean)
    .filter((image) => !image.startsWith("/uploads/") || existsSync(path.join(process.cwd(), "public", image)));

  return cleaned.length ? cleaned : ["/icon.png"];
}

function cleanPublicImage(image: string | null | undefined) {
  const value = String(image || "").trim();
  if (!value) return "/icon.png";
  if (value.startsWith("/uploads/") && !existsSync(path.join(process.cwd(), "public", value))) return "/icon.png";
  return value;
}

function mapProduct(row: {
  product: typeof products.$inferSelect;
  brandName: string | null;
  categoryName: string | null;
}): PublicProduct {
  const product = row.product;

  const specs = Object.entries(product.specifications || {}).map(
    ([key, value]) => `${key}: ${value}`
  );

  const imageList = cleanImages(product.images);

  return {
    id: product.id,
    slug: product.slug,
    name: product.name,
    brand: row.brandName || "Unbranded",
    category: row.categoryName || "Electronics",
    retailPrice: Number(product.salePrice || product.retailPrice),
    wholesalePrice: Number(product.wholesalePrice || product.retailPrice),
    moq: product.minimumWholesaleQty,
    stock:
      product.availability === "preorder"
        ? "Pre-order"
        : product.availability === "out_of_stock" || product.stock === 0
        ? "Out of stock"
        : product.stock <= product.lowStockThreshold
        ? "Limited stock"
        : "Ready stock",
    image: imageList[0],
    images: imageList,
    accent: "#e8e4df",
    description:
      product.shortDescription ||
      product.description ||
      "Authentic electronics supplied by Best Tech Bangladesh.",
    specs: specs.length
      ? specs
      : [
          product.warranty || "Warranty as stated on invoice",
          `${product.stock} units available`,
        ],
    isFeatured: product.isFeatured,
    isTopSelling: product.isTopSelling,
    showOnHome: product.showOnHome,
  };
}

export async function getPublicProducts(): Promise<PublicProduct[]> {
  if (!databaseConfigured()) return fallbackProducts;

  const db = getDb();

  const rows = await db
    .select({
      product: products,
      brandName: brands.name,
      categoryName: categories.name,
    })
    .from(products)
    .leftJoin(brands, eq(products.brandId, brands.id))
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(and(eq(products.status, "published"), eq(products.isPublished, true)))
    .orderBy(desc(products.updatedAt));

  return rows.map(mapProduct);
}

export async function getPublicProduct(slug: string) {
  if (!databaseConfigured()) {
    return fallbackProducts.find((product) => product.slug === slug) || null;
  }

  const db = getDb();

  const rows = await db
    .select({
      product: products,
      brandName: brands.name,
      categoryName: categories.name,
    })
    .from(products)
    .leftJoin(brands, eq(products.brandId, brands.id))
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(
      and(
        eq(products.slug, slug),
        eq(products.status, "published"),
        eq(products.isPublished, true)
      )
    );

  return rows[0] ? mapProduct(rows[0]) : null;
}

export async function getPublicBrands(): Promise<PublicBrand[]> {
  if (!databaseConfigured()) {
    return fallbackBrands.map((brand) => ({
      name: brand.name,
      line: brand.line,
      detail: brand.detail,
    }));
  }

  return (
    await getDb()
      .select()
      .from(brands)
      .where(eq(brands.isActive, true))
      .orderBy(asc(brands.sortOrder), asc(brands.name))
  ).map((brand) => ({
    id: brand.id,
    name: brand.name,
    slug: brand.slug,
    line: "Global technology partner",
    detail: brand.description || "Authentic products supplied across Bangladesh.",
    logoUrl: brand.logoUrl || undefined,
  }));
}

export async function getPublicCategories(): Promise<PublicCategory[]> {
  if (!databaseConfigured()) return [];

  return (
    await getDb()
      .select()
      .from(categories)
      .where(eq(categories.isActive, true))
      .orderBy(asc(categories.sortOrder), asc(categories.name))
  ).map((category) => ({
    id: category.id,
    name: category.name,
    slug: category.slug,
    description: category.description || "Explore our selected technology range.",
    imageUrl: category.imageUrl || undefined,
    icon: category.icon || undefined,
  }));
}

export async function getPublicSlides(): Promise<PublicSlide[]> {
  if (!databaseConfigured()) return fallbackSlides;

  const rows = await getDb()
    .select()
    .from(sliders)
    .where(eq(sliders.isActive, true))
    .orderBy(asc(sliders.sortOrder), asc(sliders.id));

  return rows.length
    ? rows.map((slide) => ({
        id: slide.id,
        eyebrow: slide.eyebrow || "Best Tech",
        title: slide.title,
        copy:
          slide.description ||
          "Authentic electronics and dependable supply across Bangladesh.",
        image: slide.imageUrl,
        position: slide.imagePosition || "center",
        primary: slide.buttonLabel || "Explore products",
        href: slide.buttonUrl || "/catalog",
        secondary: slide.secondaryButtonLabel || "Contact us",
        secondaryHref: slide.secondaryButtonUrl || "/contact",
      }))
    : fallbackSlides;
}

function fallbackBlogPosts(): PublicBlogPost[] {
  return fallbackPosts.map((post) => ({
    ...post,
    author: "Best Tech editorial team",
    content:
      "<p>Technology purchases should begin with the intended use, dependable sourcing, warranty support, and long-term business value.</p><h2>Start with the real requirement</h2><p>Compare products around the work they need to perform and the support required after purchase.</p>",
  }));
}

export async function getPublicBlogPosts(): Promise<PublicBlogPost[]> {
  if (!databaseConfigured()) return fallbackBlogPosts();

  const rows = await getDb()
    .select()
    .from(blogPosts)
    .where(eq(blogPosts.status, "published"))
    .orderBy(desc(blogPosts.publishedAt), desc(blogPosts.updatedAt));

  return rows.map((post) => ({
    id: post.id,
    slug: post.slug,
    title: post.title,
    excerpt:
      post.excerpt || "Read the latest technology insight from Best Tech.",
    date: (post.publishedAt || post.updatedAt).toLocaleDateString("en-BD", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }),
    category: post.category || "Insights",
    image: cleanPublicImage(post.coverImage || post.ogImage),
    coverAlt: post.coverAlt || post.title,
    author: post.authorName || "Best Tech editorial team",
    content: post.content,
    seoTitle: post.seoTitle || undefined,
    seoDescription: post.seoDescription || undefined,
    faq: post.faq || [],
  }));
}

export async function getPublicBlogPost(slug: string) {
  if (!databaseConfigured()) {
    return fallbackBlogPosts().find((post) => post.slug === slug) || null;
  }

  const rows = await getDb()
    .select()
    .from(blogPosts)
    .where(and(eq(blogPosts.slug, slug), eq(blogPosts.status, "published")));

  const post = rows[0];

  if (!post) return null;

  return {
    id: post.id,
    slug: post.slug,
    title: post.title,
    excerpt:
      post.excerpt || "Read the latest technology insight from Best Tech.",
    date: (post.publishedAt || post.updatedAt).toLocaleDateString("en-BD", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }),
    category: post.category || "Insights",
    image: cleanPublicImage(post.coverImage || post.ogImage),
    coverAlt: post.coverAlt || post.title,
    author: post.authorName || "Best Tech editorial team",
    content: post.content,
    seoTitle: post.seoTitle || undefined,
    seoDescription: post.seoDescription || undefined,
    faq: post.faq || [],
  } satisfies PublicBlogPost;
}


